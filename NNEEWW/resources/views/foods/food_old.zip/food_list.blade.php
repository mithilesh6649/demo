 @if(isset($foods))
   <ul style="list-style: none;padding: 0;">
                                          
                                     
 @forelse ($foods as $food)
     
          <li class="p-3 border-bottom">
         <div class="d-flex align-items-center">
             <div class="pl-3">
                <img width="50" src="{{@$food['food']['image']}}">
             </div>
             <div class="px-5">
                 <p class="font-weight-bold m-0">  {{@$food['food']['label']}}</p>
                 <small>kcal : {{ round(@$food['food']['nutrients']['ENERC_KCAL'], 2) }}
                        </small>   
             </div>
             <div>
                 
                @if(in_array(@$food['food']['foodId'],$allFoodIds))
                   <button disabled class="btn btn-success" food-id="{{ @$food['food']['foodId'] }}">Already added</button>
                @else
                 <button class="btn btn-primary food_add" food-id="{{ @$food['food']['foodId'] }}" food-image="{{ @$food['food']['image'] }}">Add</button>
                @endif

                 
             </div>
         </div>
        </li>
  
 @empty
 <div class="empty_content">
    <br>
    <p style="text-align: center;color: #666666;"><b>No Result Found!</b></p>
</div>
@endforelse
 </ul>
@endif