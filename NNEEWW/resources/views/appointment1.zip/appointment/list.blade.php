@extends('adminlte::page')

@section('title', 'Super Admin | Appointments')

@section('content_header')

@section('content')

<div class="container-fluid p-0">
    <div class="alert d-none" role="alert" id="flash-message">
    </div>
    <div class="col-md-12">
        <div class="card order_outer rounded_circle">
            <div class="card-body rounded_circle table p-0 mb-0">
                <div class="order_details">
                    <div class="card-main pt-3">
                        <div class="order_heading alert d-flex align-items-center justify-content-between mb-4">
                            <h3 class="mb-0"> Appointments</h3>

                            @if($ConfidentialApiKey->value != '') 
                            <a class="btn btn-sm btn-success add-advance-options" href="{{ route('add_appointment') }}">Add Appointment</a>
                            @else
                            <a class="btn btn-sm btn-success add_appointment add-advance-options" >Add Appointment</a>
                            @endif
                        </div>
                        <div class="">
                            <div>
                                 <label>Select appointment type</label>
                                 <select class="form-control" style="width:fit-content;">
                                 <option value="">Select Appointment type</option>   
                                 <option value="2">Scheduled</option>
                                 <option value="1">Requested</option>
                                 <option value="3">Appointment End</option>
                             </select>
                         </div>
                         <table style="width:100%" id="pages-list" class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th class="display-none"></th>
                                    <th>User</th>
                                    <th>Nutritionst</th>
                                    <th>Date</th>
                                    <th>Start</th>
                                    <th>End Time</th>
                                    <th>Duration</th>
                                    <th>Zoom Meeting</th>
                                    <th>Status</th>
                                    <th>Action</th>

                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($AppointmentList as $data)
                                <tr>
                                    <td class="display-none"></td>
                                    <td>{{@$data->User->name}}</td>




                                    <td>{{@$data->Nutritionist->name}}</td>



                                    <td>{{date('d/m/Y',strtotime(@$data->AppointmentMetaData->appointment_time))}}</td> 

                                    <td>{{@$data->AppointmentMetaData->start_time==null ?"--":date('g:i A', strtotime(@$data->AppointmentMetaData->start_time))}}</td>

                                    <td>{{@$data->AppointmentMetaData->end_time==null?"--":date('g:i A', strtotime(@$data->AppointmentMetaData->end_time))}}</td>

                                    <td>
                                        @if(!empty(@$data->AppointmentMetaData->start_time) && !empty(@$data->AppointmentMetaData->end_time))
                                        {{@$data->AppointmentMetaData->calculated_duration}} Min
                                        @else
                                        --  
                                        @endif
                                    </td>

                                    <td>
                                     @if(!empty(@$data->AppointmentMetaData->start_time) && !empty(@$data->AppointmentMetaData->end_time))

                                     <!-- <span class="border p-1 px-2 bg-dark copy_btn" data-link="{{@$data->AppointmentMetaData->appointment_join_url}}" title="{{@$data->AppointmentMetaData->appointment_join_url}}" >Copy</span> -->

                                     <span class="badge badge-pill badge-dark mb-1 copy_btn" style="font-size:12px;" data-link="{{@$data->AppointmentMetaData->appointment_join_url}}" title="{{@$data->AppointmentMetaData->appointment_join_url}}" >Copy  </span>
                                     <!-- <span class="badge badge-pill badge-warning notify_btn" style="font-size:12px;" >Notify</span> -->
                                     @else
                                     --  
                                     @endif

                                 </td>


                                 <td>{{@$data->AppointmentMetaData->AppointmentStatus->name}}</td>






                                 @if(!empty(@$data->AppointmentMetaData->start_time) && !empty(@$data->AppointmentMetaData->end_time))

                                 <td>

                                    <i title="Notify both by sending mail" class="fa fa-bell notify_btn" aria-hidden="true" data-id="{{@$data->id}}"></i>

                                    <a class="action-button" title="View"
                                    href="{{ route('view_appointment', ['id' => $data->id]) }}"><i
                                    class="text-success fa fa-eye"></i></a>

                                    <a href="{{ route('edit_appointment', ['id' => $data->AppointmentMetaData->id]) }}"
                                        title="Edit"><i class="text-warning fa fa-edit"></i></a>

                                        <a class="action-button delete-button" title="Delete"
                                        href="javascript:void(0)" data-id="{{ $data->id }}" meeting-id="{{@$data->AppointmentMetaData->meeting_id}}"><i
                                        class="text-danger fa fa-trash-alt"></i></a>

                                    </td>


                                    @else

                                    <td>

                                       <a class="action-button scheduled-appoinment-button" title="Schedule Appointment"
                                       href="javascript:void(0)" data-id="{{ $data->id }}" meeting-id="{{@$data->AppointmentMetaData->meeting_id}}"><i
                                       class="text-dark fa fa-calendar" style="font-size:16px;"></i></a>


                                       <a class="action-button delete-button" title="Delete"
                                       href="javascript:void(0)" data-id="{{ $data->id }}" meeting-id="{{@$data->AppointmentMetaData->meeting_id}}"><i
                                       class="text-danger fa fa-trash-alt"></i></a>

                                   </td>

                                   @endif


                               </tr>
                               @endforeach
                           </tbody>
                       </table>
                   </div>
               </div>
           </div>
       </div>
   </div>
</div>
</div>



<!-- Modal -->
<div id="myModal" class="modal  fade  " role="dialog">
  <div class="modal-dialog ">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">
          <div >
            Schedule Appoinment  :  <span class="placed_date"> </span>
        </div>

    </h4>
</div>
<div class="modal-body">

   <!--start container -->
   <div class="model-back container-fluid" id="quick_view_container">



   </div>

   <!--end container -->

</div>

</div>

</div>
</div>

<!--end modal -->

@endsection

@section('css')
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css">
<link href="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.6.1/css/bootstrap4-toggle.min.css"
rel="stylesheet">
<link href="https://harvesthq.github.io/chosen/chosen.css" rel="stylesheet" />
<link href="https://cdnjs.cloudflare.com/ajax/libs/emojionearea/3.1.5/emojionearea.min.css" rel="stylesheet" />
<link href="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.6.1/css/bootstrap4-toggle.min.css"
rel="stylesheet">
<link rel="stylesheet" type="text/css"
href="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.20/jquery.datetimepicker.css">
<link rel="stylesheet" type="text/css"
href="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.20/jquery.datetimepicker.min.css">
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet" />
<script src="//cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.js"></script>

@stop

@section('js')
<script src="https://harvesthq.github.io/chosen/chosen.jquery.js"></script>
<!-- <script src="{{ asset('docsupport/jquery-3.2.1.min.js') }}"></script> -->
<script src="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.6.1/js/bootstrap4-toggle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/emojionearea/3.1.5/emojionearea.js"></script>
<script type="text/javascript"
src="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.20/jquery.datetimepicker.full.min.js">
</script>
<script type="text/javascript"
src="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.20/jquery.datetimepicker.full.js"></script>
<script type="text/javascript"
src="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.20/jquery.datetimepicker.js"></script>
<script type="text/javascript"
src="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.20/jquery.datetimepicker.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.css">




<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script>
    $('#pages-list').DataTable({
        "order": [[ 3, "desc" ]],
        columnDefs: [{
            targets: 0,
            render: function(data, type, row) {
                return data.substr(0, 2);
            }
        }]
    });


        // delete
        //$('.delete-button').click(function(e) {
    $(document).on("click", ".delete-button", function() {
        var id = $(this).attr('data-id');
        var meeting_id = $(this).attr('meeting-id');
        var obj = $(this);

            // console.log({id});
        swal({
            title: "Are you sure?",
            text: "Are you sure you want to  delete this Appointment ?",
            type: "warning",
            showCancelButton: true,
        }, function(willDelete) {
            if (willDelete) {
                $.ajax({
                    url: "{{ route('delete_appointment') }}",
                    type: 'post',
                    data: {
                        id: id,
                        meeting_id:meeting_id
                    },
                    dataType: "JSON",
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(response) {
                        console.log("Response", response);
                        if (response.success == 1) {
                            $("#flash-message").css("display", "block");
                            $("#flash-message").removeClass("d-none");
                            $("#flash-message").addClass("alert-danger");
                            $('#flash-message').html(
                                ' Appointment  Deleted Successfully');
                            obj.parent().parent().remove();
                            setTimeout(() => {
                                $("#flash-message").addClass("d-none");
                            }, 5000);
                        } else {
                            console.log("FALSE");
                            setTimeout(() => {
                                swal('Error',
                                 response.message,
                                 'error');
                            }, 500);
                                // swal("Error!", "Something went wrong! Please try again.", "error");
                                // swal("Something went wrong! Please try again.");
                        }
                    }
                });
            }
        });
    });
        // delete
</script>
<script type="text/javascript">
        //Active and incactive choices

    $(document).ready(function() {
        $(document).on('change', '.change_status_of_status', function() {
            var id = $(this).data("id");
            var status_value = $(this).prop('checked') == true ? 1 : 0;

            $.ajax({
                type: "post",
                url: " ",
                data: {
                    "_token": "{{ csrf_token() }}",
                    id: id,
                    status_value: status_value,
                },
                success: function(response) {
                        //toastr.success(response.message);
                    console.log(response);
                }
            });
        })

            //        $('.change_status_of_group').change(function(){

            // });



    });
</script>
<script type="text/javascript">
        //Active and incactive choices

    $(document).ready(function() {
        $(document).on('change', '.change_status_of_popup', function() {
            var id = $(this).data("id");
            var status_value = $(this).prop('checked') == true ? 1 : 0;

            $.ajax({
                type: "post",
                url: "",
                data: {
                    "_token": "{{ csrf_token() }}",
                    id: id,
                    status_value: status_value,
                },
                success: function(response) {
                        //toastr.success(response.message);
                    console.log(response);
                }
            });
        })

            //        $('.change_status_of_group').change(function(){

            // });



    });

        //Copy link

        // $('#copy_btn').click(function(){
        //     var getLink = $(this).attr('data-link');
        //     alert(getLink);
        // });

    $(document).on('click','.copy_btn', function () { 
        var btn = this;
        var getLink = $(this).attr('data-link');

        var $temp = $("<input>");
        $("body").append($temp);
        $temp.val(getLink).select();
        document.execCommand("copy");
        $temp.remove();

        $(btn).html('Copied !');

        setTimeout(function(){
          $(btn).html('Copy');          
      },800);

    });

    $(document).on('click','.notify_btn', function () { 
        var btn = this;
        var getId = $(this).attr('data-id');
             // /alert(getId);  
        swal({
            title: "Are You Sure ?",
            text: "Do you want to Notify Both By Mail",
            type: "warning",
            confirmButtonText: "Send Mail",
            showCancelButton: true,
        }, function(willDelete) {
            if (willDelete) {


               $.ajax({
                   type:"POST",
                   url:"{{route('send-mail')}}",
                   data:{
                      "_token": "{{ csrf_token() }}",
                      "id": getId
                  },
                  success:function(response){


                    Swal.fire(
                      'Success',
                      'Mail Send Successfully !',
                      'success'
                      )      
                }
            });

           }
       });

    });

    $(document).on('click','.add_appointment',function(){

     swal({
        title: "Please Generate Token",
        text: "Before creating appointments you have to Generate Token .",
        type: "warning",
        confirmButtonText: "Generate Now",
        showCancelButton: true,
    }, function(willDelete) {
        if (willDelete) {
            $(location).attr('href',"{{route('edit_apiKey', ['slug' =>'zoom'])}}");
        }
    });

 });

</script>


<script>
   //  $('body').on('click', '.delete-button', function(e) {
 $(document).ready(function(){



   $('body').on('click', '.scheduled-appoinment-button', function(e) {

     $('#myModal').modal({
        'show':true,
        backdrop: 'static',
        keyboard: false
    });

     var data_id = $(this).attr('data-id');
     var order_placed_date = $(this).attr('order-placed-on');

     var obj = $(this);

     $.ajax({
         type:"post",
         url:"{{route('scheduled_appointment')}}",
         data:{
           "_token": "{{ csrf_token() }}",
           "id": data_id
       },
       dataType: "JSON",
       success:function(response){
          $('.placed_date').html(order_placed_date);
          if(response.status) {
           $('#quick_view_container').html(response.html);
           $('#myModal').modal({
            'show':true,
            backdrop: 'static',
            keyboard: false
        });

           additionalDataLinks();

       }
   }

});

 });





});





 function additionalDataLinks(){


     $( ".appoinment_date" ).datetimepicker({
            // timepicker:true,
            // formatTime: 'g:i A',
            // format : 'd/m/Y g:i A',
            // validateOnBlur: false,
            // minDate : 0,
            // step: 15,
      minDate: new Date(),
      timepicker:false,
      format:'d/m/Y'
  });


     $(".NutritionistSelect").select2({});

     $(".UserSelect").select2({
        placeholder: 'Select User',
        width: '350px',
        delay: 250,
        allowClear: true,
        minimumInputLength:false,
        ajax: {
            url: "{{route('get_active_users')}}",
            dataType: 'json',
            data: function(params) {
                return {
                    term: params.term,
                    page: params.page
                }
            },
            processResults: function (data, params) {
            //console.log(data);
                params.page = params.page || 1;
                console.log(params.page);
                console.log(data);
                var result = $.map(data, function (item) { return { id:item.id, text: item.text+"("+item.email+")"}});
                console.log(result);
                return {
                //results: result
                    results: result,
                    pagination: {
                      more: (params.page * 1) > data.total_count
                  },
              };
          },

          cache: true
      }
  });








     $(document).ready(function() {
        $('#addAppointmentForm').validate({
         ignore: [],

         rules: {
            user_id: {
                required: true
            },
            nutritionist_id: {
                required: true
            },
            appoinment_date:{
                required:true
            },
            appoinment_start_time:{
                required:true
            },
            appoinment_end_time:{
                required:true
            }

        },
  //                 errorPlacement:
  // function(error, element){
  //   var id=element[0]['id'];
  //   $( element ).before( "<label for='"+id+"' class='error'>"+error.text()+"</label>" );
  // },
        messages: {
            user_id: {
                required: "User  is required"
            },

            nutritionist_id: {
                required: "Nutritionist  is required"
            },
            appoinment_date: {
                required: "Appoinment date  is required"
            },

            appoinment_start_time: {
                required: "Appoinment start time is required"
            },
            appoinment_end_time: {
                required: "Appoinment end time is required"
            },

        },
    });

    });

 }

</script>


@stop
