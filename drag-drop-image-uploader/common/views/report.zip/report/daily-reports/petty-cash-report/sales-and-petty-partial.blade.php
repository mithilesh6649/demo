@forelse($daily_petty_expense_report as $report)
    <tr>
        {{-- <td>{{$report->id}}</td> --}}
        {{-- <td>{{$report->Branch->title_en}}</td> --}}
        <td>
            {{$report['sub_category']['sub_cat_name']}}
        </td>
        <td>{{$report->decription}}</td>
        <td>{{$report->doc_ref_no}}</td>
        <td>{{number_format($report->amount,3)}}</td>
        {{-- <td>{{date('d/m/Y',strtotime($report->created_at))}}</td> --}}
    </tr>
@empty
@endforelse