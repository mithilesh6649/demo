@forelse ($dates as $date)
  <tr>
    <td class="table_th" style="white-space: nowrap;padding:10px">{{ $date }}</td>

    @foreach($categories as $category)
      @foreach($category->subcategories as $subcategory)
        <td class="table_th" style="white-space: nowrap">{{\App\Models\DailyPettyExpense::getExpenseBranchWise($subcategory,date('Y-m-d',strtotime($date)))}}</td>
      @endforeach
    @endforeach
  </tr>
@empty
  
@endforelse  