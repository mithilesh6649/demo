@extends('adminlte::page')
@section('title', 'Super Admin | Sales & Petty Reporting')
@section('content_header')
@section('content')
<div class="container">
   <div class="alert d-none" role="alert" id="flash-message">
   </div>
   <div class="row justify-content-center">
      <div class="col-md-12">
         <div class="card">
            <div class="card-main">
               <div class="card-header alert d-flex justify-content-between align-items-center mx-0 pt-0">
                  <h3>Sales & Petty Reporting</h3>
<!--                   <div class="d-flex align-items-center justify-content-start">
                     <div class="card-header p-0" style="display: none; border: none;">
                        <h3></h3>
                        <a  href="#" data-toggle="collapse" data-target="#advanceOptions" class="advance-option-margin show-advance-options">Advance Options <i class="fa fa-caret-down"></i></a>
                     </div>
                     <span class="font-weight-bold"></span> 
                     <a class="action-button download-report" title="Download Report" href="javascript:void(0)" data-href="{{route('petty.cash.report.branch.download')}}"><i class="text-warning fa fa-download "></i></a>
                  </div> -->
               </div>
               <!--start filter -->
               <div class="advance_filter text-right mb-3 collapse show" id="advanceOptions">
                  <div class="advance-options" style="">
                     <div class="title">
                        <h5><i class="fa fa-filter mr-1"></i>Apply Search Filter</h5>
                     </div>
					 
                     <div class="left_option">
                        <div class="left_inner">
                        	<div class="button_input_wrap">
	                    		<div class="date_range_wrapper wrap-align-input">
	                              <div class="selected_branch mr-2">
	                              	<div class="d-block text-left">
	                              	   <label class="text-left w-100" for="city">Select Branch </label>
		                               <select class="advance_branch_search catselect form-select text-center" data-type="branch" id="branch" name="branch_id" >
		                                 {{-- <option value="0">For All Branch</option> --}}
		                                 @forelse ($all_active_branches as $branch)
		                                 <option value="{{$branch->id}}">{{ $branch->title_en }}</option>
		                                 @empty
		                                 <option class="disabled">Branch Not Found</option>
		                                 @endforelse
		                               </select>
		                            </div>
	                              </div>

		  						   <div class="date_range_wrapper wrap-align-input">
			  						   	<div class="d-block text-left">
			  						   	   <label class="text-left" for="city">Select Date </label>
				  						   <input class="input-wrap" data-type="date" type="text" id="date" name="date" value="{{date('d/m/Y')}}" style="min-width:300px;">
				  						</div>
		  							</div>
		  						</div>
		  						<div class="w-100">
		  							<h6 class="d-block p-0 mb-3" style="opacity: 0;">Select Date Range</h6>
		                            <div class="apply_reset_btn sales">
			                             <button class="apply apply-filter mr-1" style="background-color: red !important;border: none;border-radius:4px;"><i class="fas fa-paper-plane mr-2"></i>Apply</button>
			                             <button class="btn btn-primary reset-button mr-1" style="background-color:#000000;border: none;color: #ffffff;"><i class="fas fa-sync-alt mr-2" style="color: #ffffff;"></i>Reset</button>
			      <!--                        &nbsp;&nbsp; -->
			                              @can('download_sales_petty_report')
			                             <button class="action-button download-cashdeposit btn btn-danger downloaded download-report" href="javascript:void(0)" title="Download Report"><i class="download fa fa-download "></i></button>
			                             @endcan
		                            </div>
		  						</div>
	                        </div>
                        </div>
                     </div>
                  </div>
               </div>
               <!--end filter -->
               <div class="card-body table form mb-0">
                  @if (session('status'))
                  <div class="alert alert-success" role="alert">
                     {{ session('status') }}
                  </div>
                  @endif
                  <table id="order-online-users-list" class="table table-bordered table-hover yajra-datatable">
                     <thead>
                        <tr>
                            {{-- <th>SI No.</th> --}}
                            {{-- <th>Branch</th> --}}
                            <th>Expense Category</th>
                            <th>Description</th>
                            <th>Doc.Ref.No.</th>
                            <th>KD</th>
                            {{-- <th>Date</th> --}}
                        </tr>
                     </thead>
                     <tbody class=" " id="orders_list">
                        @include('report.daily-reports.petty-cash-report.sales-and-petty-partial')
                     </tbody>
                  </table>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
@endsection
@section('css')
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css">
<link href="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.6.1/css/bootstrap4-toggle.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet" />

<link href='https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/ui-lightness/jquery-ui.css' rel='stylesheet'>

<style type="text/css">
   select option:disabled {
   color: #000;
   font-weight: normal;
   background-color: #ddd;
   }
   .reports_rv_number:focus { 
   border: 1px solid red;
   padding: 2px;
   }
</style>
@stop
@section('js')
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.6.1/js/bootstrap4-toggle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.2/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script type="text/javascript"src=" https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script type="text/javascript"src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.2/js/buttons.html5.min.js"></script>
<script type="text/javascript"src="https://cdn.datatables.net/buttons/2.2.2/js/buttons.print.min.js"></script>
<script src='https://cdn.datatables.net/select/1.2.0/js/dataTables.select.min.js'></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>

<script> 
	$(document).ready(function() {
		$(document).on('change', '.advance_branch_search', function() {

			var branch_id = $('#branch').val();
			var date = $('#date').val();

			$.ajax({
				url: "{{route('sales-and-petty-filter')}}",
				method: 'post',
				data: {
					branch_id: branch_id,
					date: date,
				},
				dataType: "JSON",
				headers: {
					'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
				},
				success: function(response) {
					console.log('response');
					console.log(response);
					if(response.status) {
						$('#orders_list').html(response.html);
					}
				}
			});
		});

      $(document).on('click', '.apply-filter', function() {

         var branch_id = $('#branch').val();
         var date = $('#date').val();

         $.ajax({
            url: "{{route('sales-and-petty-filter')}}",
            method: 'post',
            data: {
               branch_id: branch_id,
               date: date,
            },
            dataType: "JSON",
            headers: {
               'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            success: function(response) {
               console.log('response');
               console.log(response);
               if(response.status) {
                  $('#orders_list').html(response.html);
               }
            }
         });
      });
      
      $(document).on('click', '.reset-button', function() {
         $('#branch').val("{{$all_active_branches[0]->id}}").trigger('change.select2');
         var branch_id = $('#branch').val();
         $('#date').val("{{date('d/m/Y')}}")
         var date = $('#date').val();

         $.ajax({
            url: "{{route('sales-and-petty-filter')}}",
            method: 'post',
            data: {
               branch_id: branch_id,
               date: date,
            },
            dataType: "JSON",
            headers: {
               'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            success: function(response) {
               console.log('response');
               console.log(response);
               if(response.status) {
                  $('#orders_list').html(response.html);
               }
            }
         });
      });
      
	});
</script> 

<script src="{{asset('session.js')}}"></script>
<script>
	$(document).on('click','.download-report',function(){
		var branch_id = $('#branch').val();
		var date = $('#date').val();
		var url = "{{url('reports/daily-reports/petty-cash-report/sales-and-petty-report-download')}}";
		url = url+'/'+branch_id+'/'+btoa(date);
		window.location = url;
	})
</script>

<script type="text/javascript"> 
	$(".catselect").select2(); 
</script>

{{-- date picker --}}
<script>
	$( "#date" ).datepicker({ 
		dateFormat: 'dd/mm/yy',
		maxDate: new Date()
	});
</script>

@stop