 @foreach($aDates as $dates)
    <tr>
      <td class="table_td">{{date('D',strtotime($dates))}}</td>
      <td class="table_td">{{date('d/M/Y',strtotime($dates))}}</td>
      @if(in_array($dates,array_keys($paymentmethod)))
          
        @foreach($headerscolumn as $bkey=>$daily_salse)
       
         @if($bkey=='amex')
            
           <td class="table_td" title="{{$daily_salse}}">{{\App\Models\DailySaleReport::getTotalAmexPay($branchs_ids,$paymentmethod[$dates]['date'])}}</td>

         @elseif($bkey=='visa')
            
            <td class="table_td" title="{{$daily_salse}}">{{\App\Models\DailySaleReport::getTotalVisaaPay($branchs_ids,$paymentmethod[$dates]['date'])}}</td>

         @elseif($bkey=='master')
            
            <td class="table_td" title="{{$daily_salse}}">{{\App\Models\DailySaleReport::getTotalMastersPay($branchs_ids,$paymentmethod[$dates]['date'])}}</td>

         @elseif($bkey=='dinner')
            
            <td class="table_td" title="{{$daily_salse}}">{{\App\Models\DailySaleReport::getTotalDinnerPay($branchs_ids,$paymentmethod[$dates]['date'])}}</td>

         @elseif($bkey=='mm_online_link')
            
            <td class="table_td" title="{{$daily_salse}}">{{\App\Models\DailySaleReport::getTotalPaymentGetwaysPay($branchs_ids,$paymentmethod[$dates]['date'])}}</td>

        @elseif($bkey=='knet')
            
            <td class="table_td" title="{{$daily_salse}}">{{\App\Models\DailySaleReport::getTotalKnetsPay($branchs_ids,$paymentmethod[$dates]['date'])}}</td>

         @elseif($bkey=='other_cards')
            
            <td class="table_td" title="{{$daily_salse}}">{{\App\Models\DailySaleReport::getOthercardsPay($branchs_ids,$paymentmethod[$dates]['date'])}}</td>


        @else
          <td class="table_td" title="{{$daily_salse}}">{{number_format( (float)  $paymentmethod[$dates][$bkey], 3, '.', '')}}</td>
        @endif
          
      @endforeach

      @else
       
        @foreach($headerscolumn as $bkey=>$daily_salse)
            <td class="table_td" title="{{$daily_salse}}">{{number_format( (float) 0, 3, '.', '')}}</td>
        @endforeach
         
      @endif
      <!-- <td><a class="action-button" title="View" href="#" data-date="{{$dates}}"><i class="text-info fa fa-eye eye_green"></i></a></td> -->
   </tr>
  @endforeach