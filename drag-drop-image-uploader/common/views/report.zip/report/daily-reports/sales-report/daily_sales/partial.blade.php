 @foreach($aDates as $dates)
  <tr>
    <td class="table_td">{{date('D',strtotime($dates))}}</td>
    <td class="table_td">{{date('d/M/Y',strtotime($dates))}}</td>
    @if(in_array($dates,array_keys($dailysalesdsr)))
        
      @foreach($headerscolumn as $bkey=>$daily_salse)
     
         <td class="table_td">{{number_format( (float) $dailysalesdsr[$dates][$bkey], 3, '.', '')}} </td>
         
        
      @endforeach

    @else
     
      @foreach($headerscolumn as $bkey=>$daily_salse)
          <td class="table_td">{{number_format( (float) 0, 3, '.', '')}}</td>
      @endforeach
       
    @endif
  @can('delete_daily_sales_report')
   <td>
  <a class="action-button delete-button" title="Delete" href="javascript:void(0)" data-date="{{$dates}}"><i class="text-danger fa fa-trash-alt"></i></a>
</td>
@endcan
 </tr>
@endforeach