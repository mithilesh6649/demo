@foreach($aDates as $dates)
  <tr>
   <td class="table_td">{{date('d/M/Y',strtotime($dates))}}</td>
   <td class="table_td">{{date('D',strtotime($dates))}}</td>
    @if(in_array($dates,array_keys($dailymonthdepositbank)))
        
      @foreach($branch as $bkey=>$branch_name)
     
        @if(in_array($bkey,array_keys($dailymonthdepositbank[$dates])))
         <td class="table_td">{{number_format( (float) $dailymonthdepositbank[$dates][$bkey]['cash_deposit_in_bank'], 3, '.', '')}}</td>
           @else
         <td class="table_td">{{number_format( (float) 0, 3, '.', '')}}</td>
        @endif
        
      @endforeach

    @else
     
      @foreach($branch as $bkey=>$branch_name)
          <td class="table_td">{{number_format( (float) 0, 3, '.', '')}}</td>
      @endforeach
       
    @endif
    <!-- <td><a class="action-button" title="View" href="#" data-date="{{$dates}}"><i class="text-info fa fa-eye eye_green"></i></a></td> -->
 </tr>
@endforeach