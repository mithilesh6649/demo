@foreach(['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'] as $monthNumber => $month)
<tr>
    <td>{{$loop->iteration}}</td>
    <td>{{$month}}-{{date('y',strtotime($year))}}</td>

    {!! \App\Models\DailySaleReport::getReportByBranch($selected_branch_id,$monthNumber,$year,\App\Models\DailySaleReport::AMEX) !!}
    
    {!! \App\Models\DailySaleReport::getReportByBranch($selected_branch_id,$monthNumber,$year,\App\Models\DailySaleReport::VISA) !!}
    
    {!! \App\Models\DailySaleReport::getReportByBranch($selected_branch_id,$monthNumber,$year,\App\Models\DailySaleReport::MASTER) !!}
    
    {!! \App\Models\DailySaleReport::getReportByBranch($selected_branch_id,$monthNumber,$year,\App\Models\DailySaleReport::DINNER) !!}
    
    {!! \App\Models\DailySaleReport::getReportByBranch($selected_branch_id,$monthNumber,$year,\App\Models\DailySaleReport::PAYMENT_GATEWAY) !!}
    
    {!! \App\Models\DailySaleReport::getReportByBranch($selected_branch_id,$monthNumber,$year,\App\Models\DailySaleReport::KNET) !!}
    
    {!! \App\Models\DailySaleReport::getReportByBranch($selected_branch_id,$monthNumber,$year,\App\Models\DailySaleReport::MONTH_TOTAL) !!}

</tr>
@endforeach