@extends('adminlte::page')

@section('title', 'Super Admin | Sales Reporting')

@section('content_header')
 
@section('content')
 
 
 
    <div class="rightside_content"> 
        <div class="container-fluid p-0">
            <div class="alert d-none" role="alert" id="flash-message">
            </div>
            <div class="row justify-content-center">
                <div class="col-md-12">
                    <div class="card order_outer rounded_circle">
                        <div class="card-body rounded_circle table p-0 mb-0">

                            <div class="order_details">
                                <div class="card-main pt-3">
                                    <div class="order_heading alert d-flex align-items-center justify-content-between mb-4">
                                        <h3 class="mb-0">Daily Sales Reports</h3>
                                        <a class="btn btn-sm btn_clr btn-success" href="{{ url()->previous() }}">Back</a>
                                    </div>

                                    <div class="Branch-statement">
                                        <table class="table border Responsive-table">
                                            <thead class="t_head">
                                                <tr>
                                                    <th colspan="3" class="text-center">MUGAL MAHAL</th>
                                                </tr>
                                            </thead>
                                            <tbody class="t_body">
                                                <tr>
                                                    <th colspan="3" class="text-center body_head">BRANCH-STATEMENT OF
                                                        DALIY SALES &
                                                        CASH IN
                                                        HAND</th>
                                                </tr>
                                                <tr>
                                                    <th class="thead_one">SL:<span class="manual_system"> System
                                                            Generated</span></th>
                                                    <th class="thead_two text-center">Date:<span class="manual_system">
                                                            {{ date('d/m/Y', strtotime($daily_report_sales->updated_at)) }}</span>
                                                    </th>
                                                    <th class="thead_three text-right">Branch:
                                                        {{ @$branch_details->branch_manager->branch->title_en }}
                                                        @if (@$branch_details->branch_manager->branch->title_ar)
                                                            ({{ $branch_details->branch_manager->branch->title_ar }})
                                                        @endif
                                                    </th>
                                                </tr>
                                                   <tr>
                                                <th>RV NO:<span
                                                        class="manual_system">
                                                        <input type="text" value="{{ $daily_report_sales->rv_number }}" style="width:120px;margin-right:10px;color:black;" id="rv_number_input" disabled  report_id={{$daily_report_sales->id}}>
                                                        <i class="text-warning fa fa-edit reports_rv_number_edit" style="font-size:25px;" title="Edit Rv No"></i>

                                                         <i class="text-success fa fa-save reports_rv_number_save d-none" report-id='' style="font-size:25px;cursor: pointer;" title="Update Rv No"></i>
                                                        </span> 
                                                        <!-- <span
                                                        class="manual_system">{{ $daily_report_sales->rv_number }}</span> -->
                                                </th>
                                                <td></td>
                                                <th class="text-center">Amounts</th>
                                            </tr>
                                                <tr>
                                                    <th>GROSS SALE</th>
                                                    <td></td>
                                                    <td class="sale_content_box">
                                                        <p class="show_gross_sale amount-sale" id="show_gross_sale">KD
                                                            {{ $daily_report_sales->gross_sale }}</p>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Dine-In Restaurent</td>
                                                    <td></td>
                                                    <td><input type="number" step="0.01" name="dine_in_restaurent"
                                                            class="gross_sum" placeholder="200.000" id="dine_in_restaurent"
                                                            maxlength="100" aria-invalid="false"
                                                            value="{{ $daily_report_sales->dine_in_restaurent }}" readonly>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Dine-In Cabin</td>
                                                    <td></td>
                                                    <td><input type="number" step="0.01" name="dine_in_cabin"
                                                            class="gross_sum" placeholder="200.000" id="dine_in_cabin"
                                                            maxlength="100" aria-invalid="false"
                                                            value="{{ $daily_report_sales->dine_in_cabin }}" readonly></td>
                                                </tr>
                                                <tr>
                                                    <td>Take Away/Self Pickup</td>
                                                    <td></td>
                                                    <td><input type="number" step="0.01" name="take_away_self_pickup"
                                                            class="gross_sum" placeholder="200.000"
                                                            id="take_away_self_pickup" maxlength="100" aria-invalid="false"
                                                            value="{{ $daily_report_sales->take_away_self_pickup }}"
                                                            readonly>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Home Delivery</td>
                                                    <td></td>
                                                    <td><input type="number" step="0.01" name="home_delivery"
                                                            class="gross_sum" placeholder="200.000" id="home_delivery"
                                                            maxlength="100" aria-invalid="false"
                                                            value="{{ $daily_report_sales->home_delivery }}" readonly></td>
                                                </tr>
                                                <tr>
                                                    <td>Buffet</td>
                                                    <td></td>
                                                    <td><input type="number" step="0.01" name="buffet"
                                                            class="gross_sum" placeholder="200.000" id="buffet"
                                                            maxlength="100" aria-invalid="false"
                                                            value="{{ $daily_report_sales->buffet }}" readonly>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Talabat(TEM)</td>
                                                    <td></td>
                                                    <td><input type="number" name="talabat_TEM" class="gross_sum"
                                                            placeholder="200.000" id="talabat_TEM" maxlength="100"
                                                            aria-invalid="false"
                                                            value="{{ $daily_report_sales->talabat_TEM }}" readonly></td>
                                                </tr>
                                                <tr>
                                                    <td>Talabat(TGO)</td>
                                                    <td></td>
                                                    <td><input type="number" step="0.01" name="talabat_TGO"
                                                            class="gross_sum" placeholder="200.000" id="talabat_TGO"
                                                            maxlength="100" aria-invalid="false"
                                                            value="{{ $daily_report_sales->talabat_TGO }}" readonly></td>
                                                </tr>
                                                <tr>
                                                    <td>Deliveroo(TEM)</td>
                                                    <td></td>
                                                    <td><input type="number" step="0.01" name="deliveroo_TEM"
                                                            class="gross_sum" placeholder="200.000" id="deliveroo_TEM"
                                                            maxlength="100" aria-invalid="false"
                                                            value="{{ $daily_report_sales->deliveroo_TEM }}" readonly>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Deliveroo(TGO)</td>
                                                    <td></td>
                                                    <td><input type="number" step="0.01" name="deliveroo_TGO"
                                                            class="gross_sum" placeholder="200.000" id="deliveroo_TGO"
                                                            maxlength="100" aria-invalid="false"
                                                            value="{{ $daily_report_sales->deliveroo_TGO }}" readonly>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>V-Thru</td>
                                                    <td></td>
                                                    <td><input type="number" step="0.01" name="v_thru"
                                                            class="gross_sum" placeholder="200.000" id="v_thru"
                                                            maxlength="100" aria-invalid="false"
                                                            value="{{ $daily_report_sales->v_thru }}" readonly>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>MM Online</td>
                                                    <td></td>
                                                    <td><input type="number" step="0.01" name="mm_online"
                                                            class="gross_sum" placeholder="200.000" id="mm_online"
                                                            maxlength="100" aria-invalid="false"
                                                            value="{{ $daily_report_sales->mm_online }}" readonly>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>OSC</td>
                                                    <td></td>
                                                    <td><input type="number" step="0.01" name="osc"
                                                            class="gross_sum" placeholder="200.000" id="osc"
                                                            maxlength="100" aria-invalid="false"
                                                            value="{{ $daily_report_sales->osc }}" readonly>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Garden</td>
                                                    <td></td>
                                                    <td><input type="number" step="0.01" name="garden"
                                                            class="gross_sum" placeholder="200.000" id="garden"
                                                            maxlength="100" aria-invalid="false"
                                                            value="{{ $daily_report_sales->garden }}" readonly>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Others</td>
                                                    <td></td>
                                                    <td><input type="number" step="0.01" name="others_gross"
                                                            class="gross_sum" placeholder="200.000" id="others_gross"
                                                            maxlength="100" aria-invalid="false"
                                                            value="{{ $daily_report_sales->others_gross }}" readonly>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th>Discount & Return</th>
                                                    <td></td>
                                                    <td class="last_number sale_content_box">
                                                        <p class="show_discount_return amount-sale"
                                                            id="show_discount_return">KD
                                                            {{ $daily_report_sales->discount_return }}</p>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Discount</td>
                                                    <td></td>
                                                    <td><input type="number" step="0.01" name="discount"
                                                            class="discount_sum gross_sum" placeholder="50.000"
                                                            id="discount" maxlength="100" aria-invalid="false"
                                                            value="{{ $daily_report_sales->discount }}" readonly>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Complimentary</td>
                                                    <td></td>
                                                    <td><input type="number" step="0.01" name="complimentary"
                                                            class="discount_sum gross_sum" placeholder="50.000"
                                                            id="complimentary" maxlength="100" aria-invalid="false"
                                                            value="{{ $daily_report_sales->complimentary }}" readonly>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Sale & Return</td>
                                                    <td></td>
                                                    <td><input type="number" step="0.01" name="sale_Return"
                                                            class="discount_sum gross_sum" placeholder="200.000"
                                                            id="sale_Return" maxlength="100" aria-invalid="false"
                                                            value="{{ $daily_report_sales->sale_Return }}" readonly>
                                                    </td>
                                                </tr>
                                                <tr class="sale_content">
                                                    <th>NET SALE (After Discount & Return)</th>
                                                    <td></td>
                                                    <td class="sale_content_box">
                                                        <p class="show_net_sale amount-sale" id="show_net_sale">KD
                                                            {{ $daily_report_sales->net_sale }}</p>
                                                    </td>
                                                </tr>
                                                <!-- <tr>
                                                                                                                                                                                                                                                                                                                                            <th colspan="3" class="text-center"></th>
                                                                                                                                                                                                                                                                                                                                        </tr> -->
                                                <tr>
                                                    <th>Method Of Payment(cash/Cheque & Cash Equivalent)</th>
                                                    <td></td>
                                                    <td></td>
                                                </tr>
                                                <tr>
                                                    <th>Cash In Hand-schedule</th>
                                                    <td></td>
                                                    <td class="sale_content_box last_number">
                                                        <p class="show_cash_in_hand amount-sale" id="show_cash_in_hand">KD
                                                            {{ $daily_report_sales->cash_in_hand }}</p>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Cash In Hand-Actual</td>
                                                    <td></td>
                                                    <td class="last_number"><input type="number" step="0.01"
                                                            name="cash_in_hand_actual" class="cash_in_hand_sum gross_sum"
                                                            placeholder="1700.000" id="cash_in_hand_actual"
                                                            maxlength="100" aria-invalid="false"
                                                            value="{{ $daily_report_sales->cash_in_hand_actual }}"
                                                            readonly>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Cash-Shortage</td>
                                                    <td></td>
                                                    <td class="last_number"><input type="number" step="0.01"
                                                            name="cash_shortage" class="cash_in_hand_sum gross_sum"
                                                            placeholder="60.000" id="cash_shortage" maxlength="100"
                                                            aria-invalid="false"
                                                            value="{{ $daily_report_sales->cash_shortage }}" readonly>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Cash-Overage</td>
                                                    <td></td>
                                                    <td class="main_numbers"><input type="number" step="0.01"
                                                            name="cash_overage" class="cash_in_hand_sum gross_sum"
                                                            placeholder="60.000" id="cash_overage" maxlength="100"
                                                            aria-invalid="false"
                                                            value="{{ $daily_report_sales->cash_overage }}" readonly>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th>Card Sale</th>
                                                    <td></td>
                                                    <td class="sale_content_box">
                                                        <p class="show_cards_sale amount-sale" id="show_cards_sale">KD
                                                            {{ $daily_report_sales->cards_sale }}</p>
                                                    </td>
                                                </tr>
                                                <?php
                                                $amex = json_decode($daily_report_sales->amex, true);
                                                @$sum_amex = array_sum($amex);

                                                $visa = json_decode($daily_report_sales->visa);
                                                @$sum_visa = array_sum($visa);

                                                $master = json_decode($daily_report_sales->master);
                                                @$sum_master = array_sum($master);

                                                $dinner = json_decode($daily_report_sales->dinner);
                                                @$sum_dinner = array_sum($dinner);

                                                $mm_online_link = json_decode($daily_report_sales->mm_online_link);
                                                @$sum_mm_online_link = array_sum($mm_online_link);

                                                $knet = json_decode($daily_report_sales->knet);
                                                @$sum_knet = array_sum($knet);

                                                $other_cards = json_decode($daily_report_sales->other_cards);
                                                @$sum_other_cards = array_sum($other_cards);

                                                ?>
                                                <tr>
                                                    <td>

                                                        <a href="javascript:;"
                                                            class="btn btn-success open_amex_modal btn_ok"><i
                                                                class="fa fa-plus add_input"
                                                                aria-hidden="true"></i>Amex</a>
                                                        @if (is_array($amex))
                                                            <p class="total_entries_amex amount-sale field_add_text"
                                                                id="total_entries_amex">
                                                                {{ is_array($amex) && count($amex) > 0 ? count($amex) . ' ' . 'Field Added' : '' }}
                                                            </p>
                                                        @else
                                                            <p class="total_entries_amex amount-sale field_add_text"
                                                                id="total_entries_amex"></p>
                                                        @endif
                                                    </td>
                                                    <td></td>
                                                    <td class="last_number sale_content_box">
                                                        <p class="amex_card_show amount-sale" id="amex_card_show">
                                                            {{ @$sum_amex == null ? 0 : @$sum_amex }}</p>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <a href="javascript:;"
                                                            class="btn btn-success open_visa_modal btn_ok"><i
                                                                class="fa fa-plus add_input"
                                                                aria-hidden="true"></i>Visa</a>
                                                        @if (is_array($visa))
                                                            <p class="total_entries_visa amount-sale field_add_text"
                                                                id="total_entries_visa">
                                                                {{ is_array($visa) && count(@$visa) > 0 ? count(@$visa) . ' ' . 'Field Added' : '' }}
                                                            </p>
                                                        @else
                                                            <p class="total_entries_visa amount-sale field_add_text"
                                                                id="total_entries_visa"></p>
                                                        @endif
                                                    </td>
                                                    <td></td>
                                                    <td class="last_number sale_content_box">
                                                        <p class="visa_card_show amount-sale" id="visa_card_show">
                                                            {{ @$sum_visa == null ? 0 : @$sum_visa }}</p>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <a href="javascript:;"
                                                            class="btn btn-success open_master_modal btn_ok"><i
                                                                class="fa fa-plus add_input"
                                                                aria-hidden="true"></i>Master</a>
                                                        @if (is_array($master))
                                                            <p class="total_entries_master amount-sale field_add_text"
                                                                id="total_entries_master">
                                                                {{ is_array($master) && count(@$master) > 0 ? count(@$master) . ' ' . 'Field Added' : '' }}
                                                            </p>
                                                        @else
                                                            <p class="total_entries_master amount-sale field_add_text"
                                                                id="total_entries_master"></p>
                                                        @endif
                                                    </td>
                                                    <td></td>
                                                    <td class="last_number sale_content_box">
                                                        <p class="master_card_show amount-sale" id="master_card_show">
                                                            {{ @$sum_master == null ? 0 : @$sum_master }}</p>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <a href="javascript:;"
                                                            class="btn btn-success open_dinner_modal btn_ok"><i
                                                                class="fa fa-plus add_input"
                                                                aria-hidden="true"></i>Dinner</a>
                                                        @if (is_array($dinner))
                                                            <p class="total_entries_dinner amount-sale field_add_text"
                                                                id="total_entries_dinner">
                                                                {{ is_array($dinner) && count(@$dinner) > 0 ? count(@$dinner) . ' ' . 'Field Added' : '' }}
                                                            </p>
                                                        @else
                                                            <p class="total_entries_dinner amount-sale field_add_text"
                                                                id="total_entries_dinner"></p>
                                                        @endif
                                                    </td>
                                                    <td></td>
                                                    <td class="last_number sale_content_box">
                                                        <p class="dinner_card_show amount-sale" id="dinner_card_show">
                                                            {{ @$sum_dinner == null ? 0 : @$sum_dinner }}</p>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <a href="javascript:;"
                                                            class="btn btn-success open_mm_online_link_modal btn_ok"><i
                                                                class="fa fa-plus add_input" aria-hidden="true"></i>MM
                                                            Online Link</a>
                                                        @if (is_array($mm_online_link))
                                                            <p class="total_entries_mm_online_link amount-sale field_add_text"
                                                                id="total_entries_mm_online_link">
                                                                {{ is_array($mm_online_link) && count(@$mm_online_link) > 0 ? count(@$mm_online_link) . ' ' . 'Field Added' : '' }}
                                                            </p>
                                                        @else
                                                            <p class="total_entries_mm_online_link amount-sale field_add_text"
                                                                id="total_entries_mm_online_link"></p>
                                                        @endif
                                                    </td>
                                                    <td></td>
                                                    <td class="last_number sale_content_box">
                                                        <p class="mm_online_link_card_show amount-sale"
                                                            id="mm_online_link_card_show">
                                                            {{ @$sum_mm_online_link == null ? 0 : @$sum_mm_online_link }}
                                                        </p>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <a href="javascript:;"
                                                            class="btn btn-success open_knet_modal btn_ok"><i
                                                                class="fa fa-plus add_input"
                                                                aria-hidden="true"></i>Knet</a>
                                                        @if (is_array($knet))
                                                            <p class="total_entries_knet amount-sale field_add_text"
                                                                id="total_entries_knet">
                                                                {{ is_array($knet) && count(@$knet) > 0 ? count(@$knet) . ' ' . 'Field Added' : '' }}
                                                            </p>
                                                        @else
                                                            <p class="total_entries_knet amount-sale field_add_text"
                                                                id="total_entries_knet"></p>
                                                        @endif
                                                    </td>
                                                    <td></td>
                                                    <td class="last_number sale_content_box">
                                                        <p class="knet_card_show amount-sale" id="knet_card_show">
                                                            {{ @$sum_knet == null ? 0 : @$sum_knet }}</p>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <a href="javascript:;"
                                                            class="btn btn-success open_other_modal btn_ok"><i
                                                                class="fa fa-plus add_input" aria-hidden="true"></i>Other
                                                            Cards</a>
                                                        @if (is_array($other_cards))
                                                            <p class="total_entries_other_cards amount-sale field_add_text"
                                                                id="total_entries_other_cards">
                                                                {{ is_array($other_cards) && count(@$other_cards) > 0 ? count(@$other_cards) . ' ' . 'Field Added' : '' }}
                                                            </p>
                                                        @else
                                                            <p class="total_entries_other_cards amount-sale field_add_text"
                                                                id="total_entries_other_cards"></p>
                                                        @endif
                                                    </td>
                                                    <td></td>
                                                    <td class="last_number sale_content_box">
                                                        <p class="other_card_show amount-sale" id="other_card_show">
                                                            {{ @$sum_other_cards == null ? 0 : @$sum_other_cards }}</p>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th>Cheque/Cash Equivalent</th>
                                                    <td></td>
                                                    <td class="sale_content_box">
                                                        <p class="show_cheque_cash amount-sale" id="show_cheque_cash">KD
                                                            {{ $daily_report_sales->cheque_cash }}</p>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Cheque</td>
                                                    <td></td>
                                                    <td class="last_number"><input type="number" step="0.01"
                                                            name="cheque" class="sum_cheque gross_sum"
                                                            placeholder="20.000" id="cheque" maxlength="100"
                                                            aria-invalid="false"
                                                            value="{{ $daily_report_sales->cheque }}" readonly>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Printed Gift Card</td>
                                                    <td></td>
                                                    <td class="last_number"><input type="number" step="0.01"
                                                            name="printed_gift_card" class="sum_cheque gross_sum"
                                                            placeholder="20.000" id="printed_gift_card" maxlength="100"
                                                            aria-invalid="false"
                                                            value="{{ $daily_report_sales->printed_gift_card }}" readonly>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>E-Gift Card</td>
                                                    <td></td>
                                                    <td class="last_number"><input type="number" step="0.01"
                                                            name="e_gift_card" class="sum_cheque gross_sum"
                                                            placeholder="20.000" id="e_gift_card" maxlength="100"
                                                            aria-invalid="false"
                                                            value="{{ $daily_report_sales->e_gift_card }}" readonly>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Gift Coupon/Voucher</td>
                                                    <td></td>
                                                    <td class="last_number"><input type="number" step="0.01"
                                                            name="gift_coupon_voucher" class="sum_cheque gross_sum"
                                                            placeholder="20.000" id="gift_coupon_voucher" maxlength="100"
                                                            aria-invalid="false"
                                                            value="{{ $daily_report_sales->gift_coupon_voucher }}"
                                                            readonly>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Cash Equivalent(others)</td>
                                                    <td></td>
                                                    <td class="last_number"><input type="number" step="0.01"
                                                            name="cash_equivalent" class="sum_cheque gross_sum"
                                                            placeholder="20.000" id="cash_equivalent" maxlength="100"
                                                            aria-invalid="false"
                                                            value="{{ $daily_report_sales->cash_equivalent }}" readonly>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th>Credit Sale</th>
                                                    <td></td>
                                                    <td class="sale_content_box">
                                                        <p class="show_credit_sale amount-sale" id="show_credit_sale">KD
                                                            {{ $daily_report_sales->credit_sale }}</p>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Talabat Credit</td>
                                                    <td></td>
                                                    <td class="last_number"><input type="number" step="0.01"
                                                            name="talabat_credit" class="credit_sum gross_sum"
                                                            placeholder="50.000" id="talabat_credit" maxlength="100"
                                                            aria-invalid="false"
                                                            value="{{ $daily_report_sales->talabat_credit }}" readonly>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Deliveroo Credit</td>
                                                    <td></td>
                                                    <td class="last_number"><input type="number" step="0.01"
                                                            name="deliveroo_credit" class="credit_sum gross_sum"
                                                            placeholder="50.000" id="deliveroo_credit" maxlength="100"
                                                            aria-invalid="false"
                                                            value="{{ $daily_report_sales->deliveroo_credit }}" readonly>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>V Thru Credit</td>
                                                    <td></td>
                                                    <td class="last_number"><input type="number" step="0.01"
                                                            name="v_thru_credit" class="credit_sum gross_sum"
                                                            placeholder="50.000" id="v_thru_credit" maxlength="100"
                                                            aria-invalid="false"
                                                            value="{{ $daily_report_sales->v_thru_credit }}" readonly>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Others</td>
                                                    <td></td>
                                                    <td class="last_number"><input type="number" step="0.01"
                                                            name="others_credit" class="credit_sum gross_sum"
                                                            placeholder="50.000" id="others_credit" maxlength="100"
                                                            aria-invalid="false"
                                                            value="{{ $daily_report_sales->others_credit }}" readonly>
                                                    </td>
                                                </tr>
                                                <tr class="sale_content">
                                                    <th>Total Collection</th>
                                                    <td></td>
                                                    <td class="last_number sale_content_box">
                                                        <p class="show_total_collection amount-sale"
                                                            id="show_total_collection">KD
                                                            {{ $daily_report_sales->total_collection }}</p>
                                                    </td>
                                                </tr>

                                                <tr class="table_second_heading">
                                                    <td></td>
                                                    <th>Cash in Hand Opening Balance = </th>
                                                    <td class="sale_content_box">
                                                        <p class="cash_in_hand_opening_balance amount-sale"
                                                            id="cash_in_hand_opening_balance">
                                                            {{ $daily_report_sales->cash_in_hand_opening_balance }}</p>
                                                    </td>
                                                </tr>
                                                <tr class="table_second_heading">
                                                    <td></td>
                                                    <th>(+)Cash Sales</th>
                                                    <td class="sale_content_box">
                                                        <p class="get_cash_sales para-table amount-sale"
                                                            id="get_cash_sales">{{ $daily_report_sales->cash_sales }}</p>
                                                </tr>
                                                <tr class="table_second_heading">
                                                    <td></td>
                                                    <th>(-)Cash Deposit In Bank</th>
                                                    <td><input type="number" step="0.01" name="cash_deposit_in_bank"
                                                            class="total_cash_handel gross_sum" placeholder="800"
                                                            id="cash_deposit_in_bank" maxlength="100"
                                                            aria-invalid="false"
                                                            value="{{ $daily_report_sales->cash_deposit_in_bank }}"
                                                            readonly>
                                                    </td>
                                                </tr>
                                                <tr class="table_second_heading sale_content">
                                                    <td></td>
                                                    <th>Cash in Hand Closing Balance =</th>
                                                    <td class="sale_content_box">
                                                        <p class="show_cash_in_hand_closing_balance amount-sale"
                                                            id="show_cash_in_hand_closing_balance amount-sale">KD
                                                            {{ $daily_report_sales->cash_in_hand_closing_balance }}</p>
                                                    </td>
                                                </tr>
                                            </tbody>
                                          
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- Card Sale Modals --}}

    {{-- Amex Card Modal --}}
    <div class="modal fade" id="amex_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Amex Card</h5>
                    <button type="button" class="close close_thumbnail" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true" class="close_modal">
                            ×
                        </span>
                    </button>
                </div>
                <div class="modal-body" class="add_amex_amounts">

                    <span id="add_multiple_amex">
                        @if ($amex != null)
                            @foreach ($amex as $a)
                                <span class="d-flex align-items-center mt-1"><input type="number" step="0.01"
                                        class="amex_input_value input_card gross_sum margin-unset" maxlength="100"
                                        aria-invalid="false" value="{{ $a }}" readonly>
                                </span>
                            @endforeach
                        @endif
                    </span>

                </div>
            </div>
        </div>
    </div>
    {{-- ---------- --}}

    {{-- Visa Card Modal --}}
    <div class="modal fade" id="visa_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Visa Card</h5>
                    <button type="button" class="close close_thumbnail" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true" class="close_modal">
                            ×
                        </span>
                    </button>
                </div>
                <div class="modal-body" class="add_visa_amounts">

                    <span id="add_multiple_visa">
                        @if ($visa != null)
                            @foreach ($visa as $v)
                                <span class="d-flex align-items-center mt-1"><input type="number" step="0.01"
                                        class="visa_input_value input_card gross_sum margin-unset" maxlength="100"
                                        aria-invalid="false" value="{{ $v }}" readonly>
                                </span>
                            @endforeach
                        @endif
                    </span>


                </div>
            </div>
        </div>
    </div>
    {{-- ---------- --}}

    {{-- Master Card Modal --}}
    <div class="modal fade" id="master_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Master Card</h5>
                    <button type="button" class="close close_thumbnail" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true" class="close_modal">
                            ×
                        </span>
                    </button>
                </div>
                <div class="modal-body" class="add_master_amounts">

                    <span id="add_multiple_master">
                        @if ($master != null)
                            @foreach ($master as $m)
                                <span class="d-flex align-items-center mt-1"><input type="number" step="0.01"
                                        class="master_input_value input_card gross_sum margin-unset" maxlength="100"
                                        aria-invalid="false" value="{{ $m }}" readonly>
                                </span>
                            @endforeach
                        @endif
                    </span>

                </div>
            </div>
        </div>
    </div>
    {{-- ---------- --}}

    {{-- Dinner Card Modal --}}
    <div class="modal fade" id="dinner_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Dinner Card</h5>
                    <button type="button" class="close close_thumbnail" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true" class="close_modal">
                            ×
                        </span>
                    </button>
                </div>
                <div class="modal-body" class="add_dinner_amounts">

                    <span id="add_multiple_dinner">
                        @if ($dinner != null)
                            @foreach ($dinner as $d)
                                <span class="d-flex align-items-center mt-1"><input type="number" step="0.01"
                                        class="dinner_input_value input_card gross_sum margin-unset" maxlength="100"
                                        aria-invalid="false" value="{{ $d }}" readonly>
                                </span>
                            @endforeach
                        @endif
                    </span>

                </div>
            </div>
        </div>
    </div>
    {{-- ---------- --}}

    {{-- MM Online Link Card Modal --}}
    <div class="modal fade" id="mm_online_link_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">MM Online Link Card</h5>
                    <button type="button" class="close close_thumbnail" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true" class="close_modal">
                            ×
                        </span>
                    </button>
                </div>
                <div class="modal-body" class="add_mm_online_link_amounts">

                    <span id="add_multiple_mm_online_link">
                        @if ($mm_online_link != null)
                            @foreach ($mm_online_link as $mm)
                                <span class="d-flex align-items-center mt-1"><input type="number" step="0.01"
                                        class="mm_online_link_input_value input_card gross_sum margin-unset"
                                        maxlength="100" aria-invalid="false" value="{{ $mm }}" readonly>
                                </span>
                            @endforeach
                        @endif
                    </span>

                </div>
            </div>
        </div>
    </div>
    {{-- ---------- --}}

    {{-- Knet Card Modal --}}
    <div class="modal fade" id="knet_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Knet Card</h5>
                    <button type="button" class="close close_thumbnail" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true" class="close_modal">
                            ×
                        </span>
                    </button>
                </div>
                <div class="modal-body" class="add_knet_amounts">

                    <span id="add_multiple_knet">
                        @if ($knet != null)
                            @foreach ($knet as $k)
                                <span class="d-flex align-items-center mt-1"><input type="number" step="0.01"
                                        class="knet_input_value input_card gross_sum margin-unset" maxlength="100"
                                        aria-invalid="false" value="{{ $k }}" readonly>
                                </span>
                            @endforeach
                        @endif
                    </span>

                </div>
            </div>
        </div>
    </div>
    {{-- ---------- --}}

    {{-- Other Card Modal --}}
    <div class="modal fade" id="other_card_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Other Cards</h5>
                    <button type="button" class="close close_thumbnail" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true" class="close_modal">
                            ×
                        </span>
                    </button>
                </div>
                <div class="modal-body" class="add_other_card_amounts">

                    <span id="add_multiple_other">
                        @if ($other_cards != null)
                            @foreach ($other_cards as $oc)
                                <span class="d-flex align-items-center mt-1"><input type="number" step="0.01"
                                        class="other_input_value input_card gross_sum margin-unset" maxlength="100"
                                        aria-invalid="false" value="{{ $oc }}" readonly>
                                </span>
                            @endforeach
                        @endif
                    </span>

                </div>
            </div>
        </div>
    </div>
    {{-- ---------- --}}

    {{-- --------------- --}}
@endsection

@section('css')

   <style>

    *{
    padding: 0;
    margin: 0;
    list-style: none;
    color: #000000; 
    outline-style: none;
    font-size: 16px;
    font-family: 'libre_baskervillebold';
}
@font-face {
    font-family: '../fonts/libre_baskervillebold';
    src: url('librebaskerville-bold-webfont.woff2') format('woff2'),
         url('librebaskerville-bold-webfont.woff') format('woff');
    font-weight: normal;
    font-style: normal;

}
@font-face {
    font-family: '../fonts/libre_baskervilleitalic';
    src: url('librebaskerville-italic-webfont.woff2') format('woff2'),
         url('librebaskerville-italic-webfont.woff') format('woff');
    font-weight: normal;
    font-style: normal;

}
@font-face {
    font-family: '../fonts/libre_baskervilleregular';
    src: url('librebaskerville-regular-webfont.woff2') format('woff2'),
         url('librebaskerville-regular-webfont.woff') format('woff');
    font-weight: normal;
    font-style: normal;

}
.Branch-statement .table td, .table th {
    vertical-align: top;
   /* border-top: 1px solid #dee2e6;*/
    border: 1px solid #dee2e6;
}
.Branch-statement {
    width: 100%;
    background-color: #f6f7fb;
}
.Branch-statement table {
    background-color: #ffffff;
    border: 1px solid #dee2e6;
    border-radius: 10px;
    text-align: center;
}
.Branch-statement .table td{
    padding: 8px 10px !important;
}
.Branch-statement .table td {
    font-size: 14px;
    vertical-align: middle;
    color: #212529;
    text-align: right;
}
.Branch-statement .table th{
    font-size: 14px;
    font-weight: 600;
    padding: 12px 10px;
    color: #000;
    border: 1px solid #dee2e6;
    text-align: left;
    vertical-align: inherit;
}
.Branch-statement .table td:hover{
    background-color: rgb(246 247 251);
}
.table_second_heading th{
    color: #000000 !important;
}
/* .sale_content{
    border-bottom: 2px solid #000000;
} */
.sale_content_box input::placeholder {
    font-weight: bold;
}
.sale_content_box{
    /* background-color: #f4312708; */
    background-color: #dee2e63b;
}
.main_numbers input::placeholder{
    color: #ff0000 !important;
    font-weight: bold;
}
.Branch-statement .table td input::placeholder {
    color: #000000;
}
.Branch-statement .table td input {
    border: none;
    width: 100%;
    text-align: right;
}

.last_number input::placeholder {
    font-weight: bold !important;
}
button.btn_clr {
    background-color: #F43127 !important;
    border: 1px solid #F43127 !important;
    padding: 8px 20px;
    text-decoration: auto;
    font-size: 14px;
    top: 0;
    order: 2;
    border-radius: 5px;
    white-space: nowrap;
}
input.gross_sum {
    text-align: center !important;
    width: 155px !important;
    padding: 9px 2px;
    border: 1px solid #dfe1eb !important;
    background: #fff;
    border-radius: 5px;
}
thead.t_head th{
    font-size: 20px !important;
    padding-top: 20px !important;
    padding-bottom: 5px !important;
}
tbody.t_body{
    border-top: 0px solid transparent !important;
}
tbody.t_body .body_head{
    font-weight: 400;
    padding-top: 10px;
    padding-bottom: 16px;
    font-size: 14px;
    border-top: 0px solid transparent !important;
}
.manual_system {
    color: #f43127;
    font-weight: 400;
    font-size: 14px;
}
.amount-sale{
    font-size: 14px !important;
}
.Branch-statement .table td.disable_text{
    padding: 8px 10px !important;
}
@media screen and (max-width: 1300px) {
    .Responsive-table{
        display: block;
        width: 100%;
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
        white-space: nowrap;
    }
}
td.gross_sum {
    background: #f9f9f9;
}
td.gross_sum input {
    background: #f9f9f9;
}
td.grossSum_view{
    background-color: #fff;
}
td.grossSum_view input{
    background-color: #fff;
}
.para-table{
    text-align: center !important;
    width: 155px !important;
    margin-left: auto;
    padding: 4px 2px;
}
td.sale_content_box p{
    text-align: center;
    width: 155px !important;
    margin-left: auto;
    padding: 5px 2px;
}
th.thead_one{
    width: 35%;
}
.thead_two{
    width: 30%;
} 
.thead_three{
    width: 35%;
}
        
   </style> 
@stop

@section('js')
<link href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

    <script>
        $(document).ready(function() {

            $('.open_amex_modal').click(function() {
                $('#amex_modal').modal('show');
            });

            $('.open_visa_modal').click(function() {
                $('#visa_modal').modal('show');
            });

            $('.open_master_modal').click(function() {
                $('#master_modal').modal('show');
            });

            $('.open_dinner_modal').click(function() {
                $('#dinner_modal').modal('show');
            });

            $('.open_mm_online_link_modal').click(function() {
                $('#mm_online_link_modal').modal('show');
            });

            $('.open_knet_modal').click(function() {
                $('#knet_modal').modal('show');
            });

            $('.open_other_modal').click(function() {
                $('#other_card_modal').modal('show');
            });

            $('.close_modal').click(function() {
                $('.modal').modal('hide');
            });
        });
    </script>


    <script type="text/javascript">
    
  $(document).ready(function(){
    
   $(document).on('click','.reports_rv_number_edit',function(){
      $('#rv_number_input').attr('disabled',false);
      var report_id =  $('#rv_number_input').attr('report_id');
     
      $('#rv_number_input').focus();
      $(".reports_rv_number_edit").addClass('d-none');
      $('.reports_rv_number_save').removeClass('d-none');
      $('.reports_rv_number_save').click(function(){
          var getInputValue = $('#rv_number_input').val();
             $.ajax({
      url:"{{route('daily-sales.update')}}",
      method:"POST",
      data:{
          report_id:report_id,
          rv_number:getInputValue,
        },
      dataType:"JSON",
      headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          },
      success:function(response){
        
        if(response.success)
            {
             toastr.success('Rv Number Updated Successfully');
             $(".reports_rv_number_edit").removeClass('d-none');
             $('.reports_rv_number_save').addClass('d-none');
               $('#rv_number_input').attr('disabled',true);
            }else{
             toastr.error('Something Went To Wrong');
            }
      

      }
    });

      });

   });

  });


</script>
@stop
