<?php
namespace App\Http\Reports;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Color;
use DateTime;
use DatePeriod;
use DateInterval;
use App\Models\DailySaleReport;
class GenerateCreditCardDailyReport
{
    public $branch_id;
    public $date_range;

    public function __construct($branch_id, $date_range)
    {
        $this->branch_id = base64_decode($branch_id);
        $this->date_range = base64_decode($date_range);
    }

    public function report()
    {
        $spreadsheet = new Spreadsheet();

        $spreadsheet
            ->setActiveSheetIndex(0)
            ->mergeCells("A1:Q1")
            ->setCellValue(
                "A1",
                "MUGHAL MAHAL  Yearly Sales Report -Credit Card FY-" . date("Y")
            )
            ->getStyle("A1:N1")
            ->getFont()
            ->setSize(16)
            ->setBold(true);

        $spreadsheet
            ->getActiveSheet()
            ->getStyle("A36:W36")
            ->getBorders()
            ->getTop()
            ->setBorderStyle(
                \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THICK
            )
            ->setColor(new Color("000000"));
        $spreadsheet
            ->getActiveSheet()
            ->getStyle("A37:W37")
            ->getBorders()
            ->getBottom()
            ->setBorderStyle(
                \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THICK
            )
            ->setColor(new Color("000000"));

        for ($i = 4; $i <= 37; $i++) {
            $oclbd = "A" . $i . ":W" . $i;
            $spreadsheet
                ->getActiveSheet()
                ->getStyle($oclbd)
                ->getBorders()
                ->getRight()
                ->setBorderStyle(
                    \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THICK
                )
                ->setColor(new Color("000000"));
        }

        $spreadsheet
            ->getActiveSheet()
            ->getStyle("A38:F38")
            ->getBorders()
            ->getBottom()
            ->setBorderStyle(
                \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THICK
            )
            ->setColor(new Color("000000"));

        $spreadsheet
            ->getActiveSheet()
            ->getStyle("F38")
            ->getBorders()
            ->getRight()
            ->setBorderStyle(
                \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THICK
            )
            ->setColor(new Color("000000"));

        for ($i = 38; $i <= 42; $i++) {
            $bord_N = "N" . $i;
            $spreadsheet
                ->getActiveSheet()
                ->getStyle($bord_N)
                ->getBorders()
                ->getRight()
                ->setBorderStyle(
                    \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THICK
                )
                ->setColor(new Color("000000"));

            $bord_G = "G" . $i;
            $spreadsheet
                ->getActiveSheet()
                ->getStyle($bord_G)
                ->getBorders()
                ->getRight()
                ->setBorderStyle(
                    \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THICK
                )
                ->setColor(new Color("000000"));
        }

        for ($i = 43; $i <= 44; $i++) {
            $bord_HN = "H" . $i . ":N" . $i;
            $spreadsheet
                ->getActiveSheet()
                ->getStyle($bord_HN)
                ->getBorders()
                ->getOutline()
                ->setBorderStyle(
                    \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THICK
                )
                ->setColor(new Color("000000"));
        }

        $spreadsheet
            ->getActiveSheet()
            ->getStyle("A2:W2")
            ->getBorders()
            ->getTop()
            ->setBorderStyle(
                \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THICK
            )
            ->setColor(new Color("000000"));

        $spreadsheet
            ->getActiveSheet()
            ->getStyle("W1:W3")
            ->getBorders()
            ->getRight()
            ->setBorderStyle(
                \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THICK
            )
            ->setColor(new Color("000000"));

        $spreadsheet
            ->getActiveSheet()
            ->getStyle("A45:N45")
            ->getBorders()
            ->getOutline()
            ->setBorderStyle(
                \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THICK
            )
            ->setColor(new Color("000000"));

        $spreadsheet
            ->getActiveSheet()
            ->getStyle("A1:W60")
            ->getBorders()
            ->getOutline()
            ->setBorderStyle(
                \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THICK
            )
            ->setColor(new Color("000000"));

        $spreadsheet
            ->getActiveSheet()
            ->getStyle("Q38:W38")
            ->getBorders()
            ->getOutline()
            ->setBorderStyle(
                \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THICK
            )
            ->setColor(new Color("000000"));

        $spreadsheet
            ->getActiveSheet()
            ->getStyle("Q39:U42")
            ->getBorders()
            ->getOutline()
            ->setBorderStyle(
                \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN
            )
            ->setColor(new Color("000000"));

        $spreadsheet
            ->getActiveSheet()
            ->getStyle("Q40:U40")
            ->getBorders()
            ->getOutline()
            ->setBorderStyle(
                \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN
            )
            ->setColor(new Color("000000"));

        $spreadsheet
            ->getActiveSheet()
            ->getStyle("U41")
            ->getBorders()
            ->getOutline()
            ->setBorderStyle(
                \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN
            )
            ->setColor(new Color("000000"));

        $spreadsheet
            ->getActiveSheet()
            ->getStyle("Q42:U42")
            ->getBorders()
            ->getTop()
            ->setBorderStyle(
                \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN
            )
            ->setColor(new Color("000000"));

        $spreadsheet
            ->getActiveSheet()
            ->getStyle("Q44:U44")
            ->getBorders()
            ->getTop()
            ->setBorderStyle(
                \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN
            )
            ->setColor(new Color("000000"));

        $spreadsheet
            ->getActiveSheet()
            ->getStyle("Q44:U44")
            ->getBorders()
            ->getTop()
            ->setBorderStyle(
                \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN
            )
            ->setColor(new Color("000000"));

        $spreadsheet
            ->getActiveSheet()
            ->getStyle("V40:V42")
            ->getBorders()
            ->getOutline()
            ->setBorderStyle(
                \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN
            )
            ->setColor(new Color("000000"));

        $spreadsheet
            ->getActiveSheet()
            ->getStyle("V41")
            ->getBorders()
            ->getOutline()
            ->setBorderStyle(
                \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN
            )
            ->setColor(new Color("000000"));

        $spreadsheet
            ->getActiveSheet()
            ->getStyle("A36:W37")
            ->getAlignment()
            ->setHorizontal(
                \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER
            );

        $spreadsheet
            ->getActiveSheet()
            ->getStyle("A2:W3")
            ->getAlignment()
            ->setHorizontal(
                \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER
            );

        $spreadsheet
            ->getActiveSheet()
            ->getRowDimension("2")
            ->setRowHeight(20, "pt");

        $spreadsheet
            ->getActiveSheet()
            ->getRowDimension("36")
            ->setRowHeight(20, "pt");

        $spreadsheet
            ->getActiveSheet()
            ->getRowDimension("39")
            ->setRowHeight(20, "pt");

        $spreadsheet
            ->getActiveSheet()
            ->getRowDimension("1")
            ->setRowHeight(30, "pt");
        $spreadsheet
            ->getActiveSheet()
            ->getRowDimension("3")
            ->setRowHeight(25, "pt");
        $spreadsheet
            ->getActiveSheet()
            ->getRowDimension("38")
            ->setRowHeight(25, "pt");

        $spreadsheet
            ->getActiveSheet()
            ->getStyle("A1")
            ->getAlignment()
            ->setHorizontal(
                \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
            );

        $spreadsheet
            ->setActiveSheetIndex(0)
            ->mergeCells("R1:W1")
            ->setCellValue(
                "R1",
                "Branch: " .
                    \App\Models\Branch::find($this->branch_id)["short_name"]
            )
            ->getStyle("R1:W1")
            ->getFont()
            ->setSize(16)
            ->setBold(true);

        $spreadsheet
            ->getActiveSheet()
            ->getStyle("R1")
            ->getAlignment()
            ->setHorizontal(
                \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER
            );

        $spreadsheet
            ->getActiveSheet()
            ->getStyle("A2:U2")
            ->getAlignment()
            ->setHorizontal(
                \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER
            );

        $spreadsheet
            ->getActiveSheet()
            ->getStyle("B2:T2")
            ->getFont()
            ->getColor()
            ->setARGB(\PhpOffice\PhpSpreadsheet\Style\Color::COLOR_GREEN);

        $spreadsheet
            ->getActiveSheet()
            ->getStyle("C2:W2")
            ->getFont()
            ->getColor()
            ->setARGB(\PhpOffice\PhpSpreadsheet\Style\Color::COLOR_GREEN);

        $spreadsheet
            ->getActiveSheet()
            ->getStyle("A36:W36")
            ->getFont()
            ->getColor()
            ->setARGB(\PhpOffice\PhpSpreadsheet\Style\Color::COLOR_BLUE);
        $spreadsheet
            ->getActiveSheet()
            ->getStyle("A37:W37")
            ->getFont()
            ->getColor()
            ->setARGB(\PhpOffice\PhpSpreadsheet\Style\Color::COLOR_BLUE);

        $spreadsheet
            ->getActiveSheet()
            ->getStyle("U4:U34")
            ->getFont()
            ->getColor()
            ->setARGB(\PhpOffice\PhpSpreadsheet\Style\Color::COLOR_GREEN);

        $spreadsheet
            ->getActiveSheet()
            ->getStyle("Q41:U42")
            ->getFont()
            ->getColor()
            ->setARGB(\PhpOffice\PhpSpreadsheet\Style\Color::COLOR_GREEN);

        $spreadsheet
            ->getActiveSheet()
            ->getStyle("V42")
            ->getFont()
            ->getColor()
            ->setARGB(\PhpOffice\PhpSpreadsheet\Style\Color::COLOR_GREEN);

        $spreadsheet
            ->getActiveSheet()
            ->getColumnDimension("C")
            ->setWidth(17);

        foreach (range("D", "W") as $columnID) {
            $spreadsheet
                ->getActiveSheet()
                ->getColumnDimension($columnID)
                ->setAutoSize(true);
        }

        $spreadsheet
            ->getActiveSheet()
            ->getColumnDimension("B")
            ->setWidth(15);

        $daily = $spreadsheet->getActiveSheet()->setTitle("Branch Daily");

        $daily->mergeCells("A2:B2")->setCellValue("A2", "A");
        $daily->mergeCells("C2:E2")->setCellValue("C2", "CC AMEX 3.25%");
        $daily->mergeCells("F2:H2")->setCellValue("F2", "CC VISA 2.25%");
        $daily->mergeCells("I2:K2")->setCellValue("I2", "CC MSTER 2.25%");
        $daily->mergeCells("L2:N2")->setCellValue("L2", "CC DINERS 3.5%");
        $daily->mergeCells("O2:Q2")->setCellValue("O2", "PAYMENT GTY 1%");
        $daily->mergeCells("R2:T2")->setCellValue("R2", "DR KNET 0.250%");
        $daily->mergeCells("U2:W2")->setCellValue("U2", "MONTH TOTAL");

        /**
         * Creating a third row in a first tab
         */

        $daily->setCellValue("A3", "S.NO");
        $daily->setCellValue("B3", "DATE");
        $daily->setCellValue("C3", "Inv Day TTL");
        $daily->setCellValue("D3", "comm");
        $daily->setCellValue("E3", "After Com TTL");
        $daily->setCellValue("F3", "Inv Day TTL");
        $daily->setCellValue("G3", "comm");
        $daily->setCellValue("H3", "After Com TTL");
        $daily->setCellValue("I3", "Inv Day TTL");
        $daily->setCellValue("J3", "comm");
        $daily->setCellValue("K3", "After Com TTL");
        $daily->setCellValue("L3", "Inv Day TTL");
        $daily->setCellValue("M3", "comm");
        $daily->setCellValue("N3", "After Com TTL");
        $daily->setCellValue("O3", "Inv Day TTL");
        $daily->setCellValue("P3", "comm");
        $daily->setCellValue("Q3", "After Com TTL");
        $daily->setCellValue("R3", "Inv Day TTL");
        $daily->setCellValue("S3", "comm");
        $daily->setCellValue("T3", "After Com TTL");
        $daily->setCellValue("U3", "Inv Day TTL");
        $daily->setCellValue("V3", "COMM");
        $daily->setCellValue("W3", "After Com TTL");

        $aDates = [];
        $oStart = new DateTime("2022-01-01");
        $oEnd = clone $oStart;
        $oEnd->add(new DateInterval("P1M"));

        while ($oStart->getTimestamp() < $oEnd->getTimestamp()) {
            $aDates[] = $oStart->format("d-M-Y");
            $oStart->add(new DateInterval("P1D"));
        }

        $dates = [];
        if ($this->date_range) {
            $date_range = explode(",", $this->date_range);
            $start_date = date(
                "Y-m-d",
                strtotime(str_replace("/", "-", $date_range[0]))
            );
            $end_date = date(
                "Y-m-d",
                strtotime(str_replace("/", "-", $date_range[1]))
            );

            if (is_string($start_date) === true) {
                $start_date = strtotime($start_date);
            }
            if (is_string($end_date) === true) {
                $end_date = strtotime($end_date);
            }
            if ($start_date > $end_date) {
                return createDateRangeArray($end_date, $start_date);
            }
            do {
                $dates[] = date("Y-m-d", $start_date);
                $start_date = strtotime("+ 1 day", $start_date);
            } while ($start_date <= $end_date);
        } else {
            for ($i = 1; $i <= date("t"); $i++) {
                $dates[] =
                    date("Y") .
                    "-" .
                    date("m") .
                    "-" .
                    str_pad($i, 2, "0", STR_PAD_LEFT);
            }
        }

        $column_count = 4;
        $counter = 1;
        foreach ($dates as $date) {
            $current_date = date("d-M-Y", strtotime($date));

            $spreadsheet
                ->getActiveSheet()
                ->getStyle("A" . $column_count)
                ->getAlignment()
                ->setHorizontal(
                    \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
                );
            $daily->setCellValue("A" . $column_count, $counter);

            $spreadsheet
                ->getActiveSheet()
                ->getStyle("B" . $column_count)
                ->getAlignment()
                ->setHorizontal(
                    \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
                );
            $daily->setCellValue("B" . $column_count, $current_date);

            $amount = $this->getReportVal($this->branch_id, $date, \App\Models\DailySaleReport::AMEX);
            $d_discount = ((double) $amount * 1.85) / 100;
            $final_amount = $amount - $d_discount;

            $spreadsheet
                ->getActiveSheet()
                ->getStyle("C" . $column_count)
                ->getAlignment()
                ->setHorizontal(
                    \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
                );
            $daily->setCellValue("C" . $column_count, $amount);

            $spreadsheet
                ->getActiveSheet()
                ->getStyle("D" . $column_count)
                ->getAlignment()
                ->setHorizontal(
                    \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
                );
            $daily->setCellValue("D" . $column_count, $d_discount);

            $spreadsheet
                ->getActiveSheet()
                ->getStyle("E" . $column_count)
                ->getAlignment()
                ->setHorizontal(
                    \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
                );
            $daily->setCellValue("E" . $column_count, $final_amount);

            $amount = $this->getReportVal($this->branch_id, $date, \App\Models\DailySaleReport::VISA);
            $g_discount = ((double) $amount * 1.85) / 100;
            $final_amount = $amount - $g_discount;

            $spreadsheet
                ->getActiveSheet()
                ->getStyle("F" . $column_count)
                ->getAlignment()
                ->setHorizontal(
                    \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
                );
            $daily->setCellValue("F" . $column_count, $amount);

            $spreadsheet
                ->getActiveSheet()
                ->getStyle("G" . $column_count)
                ->getAlignment()
                ->setHorizontal(
                    \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
                );
            $daily->setCellValue("G" . $column_count, $g_discount);

            $spreadsheet
                ->getActiveSheet()
                ->getStyle("H" . $column_count)
                ->getAlignment()
                ->setHorizontal(
                    \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
                );
            $daily->setCellValue("H" . $column_count, $final_amount);

            $amount = $this->getReportVal($this->branch_id, $date, \App\Models\DailySaleReport::MASTER);
            $j_discount = ((double) $amount * 1.85) / 100;
            $final_amount = $amount - $j_discount;

            $spreadsheet
                ->getActiveSheet()
                ->getStyle("I" . $column_count)
                ->getAlignment()
                ->setHorizontal(
                    \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
                );
            $daily->setCellValue("I" . $column_count, $amount);

            $spreadsheet
                ->getActiveSheet()
                ->getStyle("J" . $column_count)
                ->getAlignment()
                ->setHorizontal(
                    \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
                );
            $daily->setCellValue("J" . $column_count, $j_discount);

            $spreadsheet
                ->getActiveSheet()
                ->getStyle("K" . $column_count)
                ->getAlignment()
                ->setHorizontal(
                    \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
                );
            $daily->setCellValue("K" . $column_count, $final_amount);

            $amount = $this->getReportVal($this->branch_id, $date, \App\Models\DailySaleReport::DINNER);
            $m_discount = ((double) $amount * 1.85) / 100;
            $final_amount = $amount - $m_discount;

            $spreadsheet
                ->getActiveSheet()
                ->getStyle("L" . $column_count)
                ->getAlignment()
                ->setHorizontal(
                    \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
                );
            $daily->setCellValue("L" . $column_count, $amount);

            $spreadsheet
                ->getActiveSheet()
                ->getStyle("M" . $column_count)
                ->getAlignment()
                ->setHorizontal(
                    \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
                );
            $daily->setCellValue("M" . $column_count, $m_discount);

            $spreadsheet
                ->getActiveSheet()
                ->getStyle("N" . $column_count)
                ->getAlignment()
                ->setHorizontal(
                    \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
                );
            $daily->setCellValue("N" . $column_count, $final_amount);

            $amount = $this->getReportVal(
                $this->branch_id,
                $date,
                \App\Models\DailySaleReport::PAYMENT_GATEWAY
            );
            $p_discount = ((double) $amount * 1.85) / 100;
            $final_amount = $amount - $p_discount;

            $spreadsheet
                ->getActiveSheet()
                ->getStyle("O" . $column_count)
                ->getAlignment()
                ->setHorizontal(
                    \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
                );
            $daily->setCellValue("O" . $column_count, $amount);

            $spreadsheet
                ->getActiveSheet()
                ->getStyle("P" . $column_count)
                ->getAlignment()
                ->setHorizontal(
                    \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
                );
            $daily->setCellValue("P" . $column_count, $p_discount);

            $spreadsheet
                ->getActiveSheet()
                ->getStyle("Q" . $column_count)
                ->getAlignment()
                ->setHorizontal(
                    \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
                );
            $daily->setCellValue("Q" . $column_count, $final_amount);

            $amount = $this->getReportVal($this->branch_id, $date, \App\Models\DailySaleReport::KNET);
            $s_discount = ((double) $amount * 1.85) / 100;
            $final_amount = $amount - $s_discount;

            $spreadsheet
                ->getActiveSheet()
                ->getStyle("R" . $column_count)
                ->getAlignment()
                ->setHorizontal(
                    \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
                );
            $daily->setCellValue("R" . $column_count, $amount);

            $spreadsheet
                ->getActiveSheet()
                ->getStyle("S" . $column_count)
                ->getAlignment()
                ->setHorizontal(
                    \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
                );
            $daily->setCellValue("S" . $column_count, $s_discount);

            $spreadsheet
                ->getActiveSheet()
                ->getStyle("T" . $column_count)
                ->getAlignment()
                ->setHorizontal(
                    \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
                );
            $daily->setCellValue("T" . $column_count, $final_amount);

            $amount = $this->getReportVal(
                $this->branch_id,
                $date,
                \App\Models\DailySaleReport::MONTH_TOTAL
            );
            $v_discount = ((double) $amount * 1.85) / 100;
            $final_amount = $amount - $v_discount;

            $spreadsheet
                ->getActiveSheet()
                ->getStyle("U" . $column_count)
                ->getAlignment()
                ->setHorizontal(
                    \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
                );
            $daily->setCellValue("U" . $column_count, $amount);

            $spreadsheet
                ->getActiveSheet()
                ->getStyle("V" . $column_count)
                ->getAlignment()
                ->setHorizontal(
                    \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
                );
            $daily->setCellValue("V" . $column_count, $v_discount);

            $spreadsheet
                ->getActiveSheet()
                ->getStyle("W" . $column_count)
                ->getAlignment()
                ->setHorizontal(
                    \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
                );
            $daily->setCellValue("W" . $column_count, $final_amount);

            $column_count++;
            $counter++;
        }

        $daily->mergeCells("A36:B36")->setCellValue("A36", "TTL Bef Vs Aft");
        $daily->mergeCells("A37:B37")->setCellValue("A37", "Comm TTL");

        $daily->setCellValue("W3", "After Com TTL");
        $daily->setCellValue("V37", "=SUM(V36:V36)");
        $daily->setCellValue("T37", "=SUM(S36:S36)");
        $daily->setCellValue("Q37", "=SUM(P36:P36)");
        $daily->setCellValue("N37", "=SUM(M36:M36)");
        $daily->setCellValue("K37", "=SUM(J36:J36)");
        $daily->setCellValue("H37", "=SUM(H36:H36)");
        $daily->setCellValue("E37", "=SUM(D36:D36)");

        foreach (range("C", "W") as $columnID) {
            $col = $columnID . "36";
            $spreadsheet
                ->getActiveSheet()
                ->getStyle($col)
                ->getAlignment()
                ->setHorizontal(
                    \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
                );
            $daily->setCellValue(
                $col,
                "=SUM(" . $columnID . "4:" . $columnID . "35)"
            );
        }

        $daily->setCellValue("A38", "Details of  Cr & Dr Card ");
        $daily->setCellValue("A39", "A) TOTAL CREDIT CARD SALES - AMEX ");
        $daily->setCellValue("A40", "B) TOTAL CREDIT CARD SALES - VISA");
        $daily->setCellValue("A41", "C) TOTAL CREDIT CARD SALES - MASTER");
        $daily->setCellValue("A42", "D) TOTAL CREDIT CARD SALES - KNET");
        $daily->setCellValue("A43", "E) TOTAL CREDIT CARD SALES - DINERS");
        $daily->setCellValue("A44", "F) TOTAL CREDIT CARD SALES - OTHERS");
        $daily->setCellValue("F45", "Total");
        $daily->setCellValue("I45", "=SUM(H39:H44)");

        $spreadsheet
            ->getActiveSheet()
            ->getStyle("H38")
            ->getAlignment()
            ->setHorizontal(
                \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER
            );
        $daily->mergeCells("H38:I38")->setCellValue("H38", "Total");

        $spreadsheet
            ->getActiveSheet()
            ->getStyle("K38")
            ->getAlignment()
            ->setHorizontal(
                \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER
            );
        $daily->mergeCells("K38:L38")->setCellValue("K38", "Aft Comm");

        $spreadsheet
            ->getActiveSheet()
            ->getStyle("N38")
            ->getAlignment()
            ->setHorizontal(
                \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
            );
        $daily->setCellValue("N38", "Comm");

        // --------------------------------------------------------------
        $spreadsheet->getActiveSheet()->getStyle("H39")->getAlignment()
            ->setHorizontal(
                \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
            );
        $daily->mergeCells("H39:I39")->setCellValue("H39", "=SUM(C4:C35)");

        $spreadsheet->getActiveSheet()->getStyle("H40")->getAlignment()
            ->setHorizontal(
                \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
            );
        $daily->mergeCells("H40:I40")->setCellValue("H40", "=SUM(F4:F35)");

        $spreadsheet->getActiveSheet()->getStyle("H41")->getAlignment()
            ->setHorizontal(
                \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
            );
        $daily->mergeCells("H41:I41")->setCellValue("H41", "=SUM(I4:I35)");

        $spreadsheet->getActiveSheet()->getStyle("H42")->getAlignment()
            ->setHorizontal(
                \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
            );
        $daily->mergeCells("H42:I42")->setCellValue("H42", "=SUM(R4:R35)");

        $spreadsheet->getActiveSheet()->getStyle("H43")->getAlignment()
            ->setHorizontal(
                \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
            );
        $daily->mergeCells("H43:I43")->setCellValue("H43", "=SUM(L4:L35)");

        $spreadsheet->getActiveSheet()->getStyle("H44")->getAlignment()
            ->setHorizontal(
                \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
            );
        $daily->mergeCells("H44:I44")->setCellValue("H44", "0.000");
        
        $spreadsheet->getActiveSheet()->getStyle("K39")->getAlignment()
            ->setHorizontal(
                \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
            );
        $daily->mergeCells("K39:L39")->setCellValue("K39", "=SUM(D4:D35)");

        $spreadsheet->getActiveSheet()->getStyle("K40")->getAlignment()
            ->setHorizontal(
                \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
            );
        $daily->mergeCells("K40:L40")->setCellValue("K40", "=SUM(G4:G35)");

        $spreadsheet->getActiveSheet()->getStyle("K41")->getAlignment()
            ->setHorizontal(
                \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
            );
        $daily->mergeCells("K41:L41")->setCellValue("K41", "=SUM(J4:J35)");

        $spreadsheet->getActiveSheet()->getStyle("K42")->getAlignment()
            ->setHorizontal(
                \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
            );
        $daily->mergeCells("K42:L42")->setCellValue("K42", "=SUM(S4:S35)");

        $spreadsheet->getActiveSheet()->getStyle("K43")->getAlignment()
            ->setHorizontal(
                \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
            );
        $daily->mergeCells("K43:L43")->setCellValue("K43", "=SUM(M4:M35)");

        $spreadsheet->getActiveSheet()->getStyle("K44")->getAlignment()
            ->setHorizontal(
                \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
            );
        $daily->mergeCells("K44:L44")->setCellValue("K44", "0.000");



        $spreadsheet->getActiveSheet()->getStyle("N39")->getAlignment()
            ->setHorizontal(
                \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
            );
        $daily->setCellValue("N39", "=SUM(E4:E35)");

        $spreadsheet->getActiveSheet()->getStyle("N40")->getAlignment()
            ->setHorizontal(
                \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
            );
        $daily->setCellValue("N40", "=SUM(I4:I35)");

        $spreadsheet->getActiveSheet()->getStyle("N41")->getAlignment()
            ->setHorizontal(
                \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
            );
        $daily->setCellValue("N41", "=SUM(K4:K35)");

        $spreadsheet->getActiveSheet()->getStyle("N42")->getAlignment()
            ->setHorizontal(
                \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
            );
        $daily->setCellValue("N42", "=SUM(T4:T35)");

        $spreadsheet->getActiveSheet()->getStyle("N43")->getAlignment()
            ->setHorizontal(
                \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
            );
        $daily->setCellValue("N43", "=SUM(N4:N35)");

        $spreadsheet->getActiveSheet()->getStyle("N44")->getAlignment()
            ->setHorizontal(
                \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
            );
        $daily->setCellValue("N44", "0.000");
        // --------------------------------------------------------

        $spreadsheet
            ->getActiveSheet()
            ->getStyle("B49")
            ->getAlignment()
            ->setHorizontal(
                \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_LEFT
            );

        $daily->setCellValue("B49", "Notes: ");

        $spreadsheet
            ->getActiveSheet()
            ->getStyle("B50")
            ->getAlignment()
            ->setHorizontal(
                \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
            );
        $spreadsheet
            ->getActiveSheet()
            ->getStyle("B51")
            ->getAlignment()
            ->setHorizontal(
                \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
            );
        $spreadsheet
            ->getActiveSheet()
            ->getStyle("B52")
            ->getAlignment()
            ->setHorizontal(
                \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
            );

        $spreadsheet
            ->getActiveSheet()
            ->getStyle("Q39")
            ->getAlignment()
            ->setHorizontal(
                \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER
            );
        $spreadsheet
            ->getActiveSheet()
            ->getStyle("Q40")
            ->getAlignment()
            ->setHorizontal(
                \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER
            );
        $spreadsheet
            ->getActiveSheet()
            ->getStyle("Q41")
            ->getAlignment()
            ->setHorizontal(
                \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER
            );
        $spreadsheet
            ->getActiveSheet()
            ->getStyle("Q42")
            ->getAlignment()
            ->setHorizontal(
                \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER
            );

        $daily->setCellValue("B50", "1");
        $daily->setCellValue("B51", "2");
        $daily->setCellValue("B52", "3");
        $daily->setCellValue(
            "C50",
            "Amex,Visa,Master,Dinner (Credit) Comminssion 1.85%/Per 1KWD"
        );
        $daily->setCellValue("C51", "K-net (Debit) Commission .015%/Per 1KWD");
        $daily->setCellValue(
            "C52",
            "MM Pay Commssion KWD 0.150/per Transaction "
        );

        $daily
            ->mergeCells("Q38:W38")
            ->setCellValue(
                "Q38",
                "SALES A/C GBK# 5194393  DEPOSIT/TO TRANSFER "
            );
        $daily
            ->mergeCells("Q39:U39")
            ->setCellValue(
                "Q39",
                "TO DEPOSIT  BY (VISA/KNET/MASTER/OTHERS) CHQ#"
            );
        $daily
            ->mergeCells("Q40:U40")
            ->setCellValue("Q40", "DIRECT TR FROM AMEX");
        $daily
            ->mergeCells("Q41:T41")
            ->setCellValue("Q41", "BANK MACHINE RENT OF GBK");
        $daily->setCellValue("U41", "00.000");
        // $daily->mergeCells('Q42:U42');
        $daily
            ->mergeCells("Q42:U43")
            ->setCellValue(
                "Q42",
                "ACTUAL TRASFER IN SALE A/C AFTER RENT+COMM."
            );

        for ($i = 39; $i <= 42; $i++) {
            $col = "V" . $i;
            $merge_col = "V" . $i . ":W" . $i;
            $spreadsheet
                ->getActiveSheet()
                ->getStyle($col)
                ->getAlignment()
                ->setHorizontal(
                    \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER
                );
            $daily->mergeCells($merge_col)->setCellValue($col, "00.000");
        }


        $format = '0.000';
        $spreadsheet->getActiveSheet()->getStyle('C4:W45')->getNumberFormat()->setFormatCode($format);


        /* Set active sheet index to the first sheet, so Excel opens this as the first sheet */
        $spreadsheet->setActiveSheetIndex(0);
         $timestamp = "-".date('d-m-Y')."(".date('h-i-s-A',time()).")";
        $fileName = "Credit-Card-Commission-Report".$timestamp.".xlsx";
        $writer = new Xlsx($spreadsheet);
        header(
            "Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        );
        header(
            'Content-Disposition: attachment; filename="' .
                urlencode($fileName) .
                '"'
        );
        $writer->save("php://output");
    }

    public function getReportVal($branch_id, $date, $column)
    {
        try {
            $reports = DailySaleReport::where("branch_id", $branch_id)
                ->whereDate("created_at", $date)
                ->get();
            if ($column == \App\Models\DailySaleReport::MONTH_TOTAL) {
                $amount =
                    (double) $reports->sum(DailySaleReport::AMEX) +
                    (double) $reports->sum(DailySaleReport::VISA) +
                    (double) $reports->sum(DailySaleReport::MASTER) +
                    (double) $reports->sum(DailySaleReport::DINNER) +
                    (double) $reports->sum(DailySaleReport::KNET) +
                    (double) $reports->sum(DailySaleReport::PAYMENT_GATEWAY);
            } else {
                $amount = (double) $reports->sum($column);
            }
            return $amount;
        } catch (\Exception $e) {
            return 00.000;
        }
    }
}
