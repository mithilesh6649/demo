<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Branch;
use App\Models\PurchasedGiftCard;
use App\Models\GiftCardsType;
use App\Models\GiftCard;
use Auth,DB;
class GiftCardReportController extends Controller
{
   public function GiftCardsReportList(){
       if (Auth::user()->can('gift_card_tab_management')) { 
          $all_active_branches = Branch::where("status", 1)->get();
          $daily_gifts_card_report = PurchasedGiftCard::whereDate('date',date('Y-m-d'))->orderBy('date','desc')->where('branch_id',$all_active_branches[0]['id'])->get(); 
          // $daily_gifts_card_report = PurchasedGiftCard::get(); 

          return view(
            "report.gift-cards-reports.index",
            compact("daily_gifts_card_report", "all_active_branches")
        );


      }else{
       return redirect()
       ->route("dashboard")
       ->with( 
        "warning",
        "You do not have permission for this action!"
    );
   }


}  


public function GiftCardsReportView($id){
   if (Auth::user()->can('view_gift_card_report')) { 

      $all_active_branches = Branch::where("status", 1)->get();
      $gift = PurchasedGiftCard::with('branch')->where('id',$id)->first();
      return view(
        "report.gift-cards-reports.view",
        compact("gift","all_active_branches")
    );

  }else{
   return redirect()
   ->route("dashboard")
   ->with( 
    "warning",
    "You do not have permission for this action!"
);
}
}




public function GiftCardsReportDelete(Request $request){

  DB::beginTransaction();

  try {

    $PurchasedGiftCard = PurchasedGiftCard::where('id', $request->id)->first(); 
    $totalGiftCardNumber = json_decode($PurchasedGiftCard->card_number);
    
    foreach($totalGiftCardNumber as $GiftCardNumber){
        $newGifCard = GiftCard::where("card_number",$GiftCardNumber)->first();
        $newGifCard->status = 1;
        $newGifCard->is_gift_card_used = 0;
        $newGifCard->update();
    }    

    $PurchasedGiftCard = $PurchasedGiftCard->forceDelete();
    DB::commit();
    if ($PurchasedGiftCard)
    {
        $res['success'] = 1;
        return json_encode($res);
    }
    else
    {
        $res['success'] = 0;
        return json_encode($res);
    }


} catch (\Exception $e) {
    DB::rollback();
    $res['success'] = 0;
    return json_encode($res);       
}

}


public function GiftCardsReportFilter(Request $request){

    $all_active_branches = Branch::where("status", 1)->get();
    $date = str_replace("/","-",$request->date);
    $request_date = date('Y-m-d',strtotime($date));

    $daily_gifts_card_report = PurchasedGiftCard::whereDate('date',$request_date)->orderByDesc("date")->where("branch_id",$request->branch_id)->get();

    $result_view = view("report.gift-cards-reports.gift-cards-partial",[
        "daily_gifts_card_report" => $daily_gifts_card_report,
    ])->render();
    
    return json_encode(["html" => $result_view, "status" => true]);

    
} 



public function deletedGiftCardsReportList(){
 $branch=Branch::where('status','1')->get()->pluck('title_en','id');
 $allBranchDeletedReports = PurchasedGiftCard::with('Branch')->onlyTrashed()->get();
 return view('report.gift-cards-reports.deleted_list',compact('branch','allBranchDeletedReports'));
}





public function filterGiftCardsDeletedReports(Request $request){
  $allBranchDeletedReports = null; 
  if($request->with =='only_branch_id'){


    if($request->branch_id==0){
      $allBranchDeletedReports = PurchasedGiftCard::with('Branch')->onlyTrashed()->get(); 
  }

  if($request->branch_id!=0){
    $allBranchDeletedReports = PurchasedGiftCard::with('Branch')->onlyTrashed()->where('branch_id',$request->branch_id)->get();;
}


$result_view = view('report.gift-cards-reports.deleted_partial',['allBranchDeletedReports'=>$allBranchDeletedReports])->render();

return json_encode(['html'=> $result_view,'status'=>true]);

}

if($request->with=="apply_filter"){

 $first_second=date('Y-m-d',strtotime(str_replace('/','-',$request->date_range[0])));
 $last_second=date('Y-m-d',strtotime(str_replace('/','-',$request->date_range[1])));

 if($request->branch_id==0){
    $allBranchDeletedReports = PurchasedGiftCard::with('Branch')->onlyTrashed()->whereBetween('date',[$first_second,$last_second])->get();
}

if($request->branch_id!=0){
    $allBranchDeletedReports = PurchasedGiftCard::with('Branch')->onlyTrashed()->where('branch_id',$request->branch_id)->whereBetween('date',[$first_second,$last_second])->get() ;
}

$result_view = view('report.gift-cards-reports.deleted_partial',['allBranchDeletedReports'=>$allBranchDeletedReports])->render();

return json_encode(['html'=> $result_view,'status'=>true]);

}
} 








public function resetGiftCardsDeletedReports(Request $request){
    $allBranchDeletedReports = PurchasedGiftCard::with('Branch')->onlyTrashed()->get();
    $result_view = view('report.gift-cards-reports.deleted_partial',['allBranchDeletedReports'=>$allBranchDeletedReports])->render(); 
    return json_encode(['html'=> $result_view,'status'=>true]);
}


public function restoreGiftCardsReport(Request $request){
 $selected_dates = PurchasedGiftCard::withTrashed()->where('id',$request->id)->restore();
 if($selected_dates) {
    $res["success"] = 1;
    return json_encode($res);
} else {
    $res["success"] = 0;
    return json_encode($res);
}
}


public function permanentDeleteGiftCardsReport(Request $request){

  $selected_dates = PurchasedGiftCard::withTrashed()->where('id',$request->id)->forceDelete();
  if($selected_dates) {
    $res["success"] = 1;
    return json_encode($res);
} else {
    $res["success"] = 0;
    return json_encode($res);
}  

}



public function GiftCardsReportEdit($id){
   $gift=PurchasedGiftCard::where('id',$id)->first();
   return view('report.gift-cards-reports.edit',compact('gift'));
}


public function GiftCardsReportUpdate(Request $request){
   $purchased_gift_card = PurchasedGiftCard::where('id',$request->gift_id)->first();
   $purchased_gift_card->guest_name = $request->guest_name;
   $purchased_gift_card->mobile_number = $request->mobile_number;
   $purchased_gift_card->pos_invoice_number = $request->pos_invoice_no;
   $purchased_gift_card->card_amount = $request->card_amount;
   $purchased_gift_card->update();
   return redirect()->route("gift.card.report.list")->with(["success" => "  Gift Cards Report updated successfully!"]); 
}


public function GiftCardsNumberDelete(Request $request){
 
 $gift_card = GiftCard::where(['card_number'=>$request->data_card_number,'status' =>0,'is_gift_card_used' => 1])->first();

 $value_of_deleted_gift_card = GiftCardsType::where('id',$gift_card->gift_cards_type_id)->value('name');

 $allPurchsedGiftCardsAfterDelete = array();
 $PurchasedGiftCard=PurchasedGiftCard::where('id',$request->data_gift_card_id)->first();
 $allPurchsedGiftCardsArray = json_decode($PurchasedGiftCard->card_number);
 $currentCardAmount = $PurchasedGiftCard->card_amount - $value_of_deleted_gift_card;
 
   // dd($currentCardAmount);
 foreach($allPurchsedGiftCardsArray as $key => $PurchasedGiftCardNumber){
    if($PurchasedGiftCardNumber == $request->data_card_number){
        $gift_card->status =1;
        $gift_card->is_gift_card_used = 0;
        $gift_card->update();
    }else{
      array_push($allPurchsedGiftCardsAfterDelete,$PurchasedGiftCardNumber);
  }
}

$PurchasedGiftCard->card_number = json_encode($allPurchsedGiftCardsAfterDelete);
$PurchasedGiftCard->card_amount = $currentCardAmount;
if($PurchasedGiftCard->save()){
    return response()->json([
     'status'=>1,
     'card_amount'=>$currentCardAmount,
 ]);
}
}



public function GiftCardsNumberValid(Request $request){
    $card_number = $request->data_card_number;
    $gift_card = GiftCard::where(['card_number'=>$card_number,'status' =>1,'is_gift_card_used' => 0])->first();
    if($gift_card != null){
        return  response()->json([
           'status'=>1
       ]);
    }else{
       return  response()->json([
           'status'=>0
       ]);
   } 

}


public function GiftCardsNumberUpdate(Request $request){

    $PurchasedGiftCard=PurchasedGiftCard::where('id',$request->id)->first();
    $sum = 0;
    $PurchasedGiftCard->card_number = json_encode($request->data_card_numbers);
    if($PurchasedGiftCard->update()){

       foreach($request->data_card_numbers as $key => $PurchasedGiftCardNumber){
          $GiftCards = GiftCard::where('card_number',$PurchasedGiftCardNumber)->first();
          $GiftCards->status = 0;
          $GiftCards->is_gift_card_used = 1;
          $GiftCards->update();
          $value_of_deleted_gift_card = GiftCardsType::where('id',$GiftCards->gift_cards_type_id)->value('name');
          $sum = $sum+$value_of_deleted_gift_card;
          
      }

      $PurchasedGiftCard->card_amount = $sum;
      $PurchasedGiftCard->update();  

      return response()->json([
         'status'=>1,
         'card_amount'=>$sum,
     ]);
      

      
  }

}




public function GiftCardsPurchasedShow(Request $request){

   $gift=PurchasedGiftCard::where('id',$request->id)->first();

   $result_view = view("report.gift-cards-reports.gift_card_purchased", [
    "gift" => $gift,
])->render();

   return json_encode(["html" => $result_view, "status" => true]);

}



}
