<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use \App\Models\Staff;
use \App\Models\Designation;
use DB;

class StaffController extends Controller
{
    public function staffList(Request $request)
    {
        // if (Auth::user()->can('branch_managers_management')) {
        $status = DB::table('md_dropdowns')->where('slug','status_data')->get();
        $staffs = Staff::with('branchStaffs:staff_id,branch_id','branchStaffs.StaffBranch')->orderBY('id', 'desc')->get();
       // dd($staffs);
        return view('staff.staff_list', compact('staffs','status'));
        //    }else{
        //       return redirect()->route('dashboard')->with('warning', 'You do not have permission for this action!');
        //   }
    }

    public function viewStaff($id)
    {
        //    if (Auth::user()->can('view_branch_manager')) {
        $staff = Staff::find($id);
        $status = DB::table('md_dropdowns')->where('slug','status_data')->get();
        return view('staff.staff_view', compact('staff','status'));
        //   }else{
        //       return redirect()->route('dashboard')->with('warning', 'You do not have permission for this action!');
        //   }
    }

    public function addStaff()
    {
        // if (Auth::user()->can('add_branch_manager')) {
        $designation_list = Designation::where('status','1')->get();
        $status = DB::table('md_dropdowns')->where('slug','status_data')->get();
        return view('staff.staff_add',compact('designation_list','status'));
        //     }else{
        //       return redirect()->route('dashboard')->with('warning', 'You do not have permission for this action!');
        //   }
    }

    public function saveStaff(Request $request)
    {

        $staff = new Staff;
        $staff->staff_name = $request->staff_name;
        $staff->staff_code = $request->staff_code;
        $staff->designation_id = $request->designation;
        $staff->civil_id = $request->civil_id;
        $staff->status = $request->status;

        if($request->points != NULL && $request->points != ''){
            $staff->points = $request->points;
        }

        if ($staff->save()) {
            return redirect()->route('staff_list')->with('success', 'Staff has been added successfully!');
        } else {
            return redirect()->back()->with('warning', 'Something went wrong!');
        }

    }

    public function deleteStaff(Request $request)
    {
        $deleteStaff = Staff::where('id', $request->id)->delete();
        if ($deleteStaff) {
            $res['success'] = 1;
            return json_encode($res);
        } else {
            $res['success'] = 0;
            return json_encode($res);
        }
    }

    public function editStaff($id)
    {
        //    if (Auth::user()->can('edit_branch_manager')) {
        $staff = Staff::find($id);
        $designation_list = Designation::where('status','1')->get();
        $status = DB::table('md_dropdowns')->where('slug','status_data')->get();

        return view('staff.staff_edit', compact('staff','designation_list','status'));
        //   }else{
        //       return redirect()->route('dashboard')->with('warning', 'You do not have permission for this action!');
        //   }
    }

    public function updateStaff(Request $request)
    {

        $staff = Staff::find($request->id);
        $staff->staff_name = $request->staff_name;
        $staff->staff_code = $request->staff_code;
        $staff->designation_id = $request->designation;
        $staff->civil_id = $request->civil_id;
        $staff->status = $request->status;

        if($request->points != NULL && $request->points != ''){
            $staff->points = $request->points;
        }

        if ($staff->save()) {
            return redirect()->route('staff_list')->with(['success' => 'Staff details has been updated successfully!']);
        } else {
            return redirect()->back()->with('warning', 'Something went wrong!');
        }
    }

    public function checkstaffcode(Request $request){

        if($request->has('id')){
            $data=Staff::where(['staff_code'=>$request->staff_code])->where('id','!=',$request->id)->get();
        }else{
            $data=Staff::where(['staff_code'=>$request->staff_code])->get();
        }

        if(count($data)>0){
            return response()->json(['msg'=>'true']);
        }else{
            return response()->json(['msg'=>'false']);
        }

    }

}
