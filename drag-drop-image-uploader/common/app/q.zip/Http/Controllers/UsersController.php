<?php

namespace App\Http\Controllers;

use App\Models\Role;
use App\Models\User;
use Auth;
use DB;
use Illuminate\Http\Request;

class UsersController extends Controller
{
    public function usersList()
    {

        if (Auth::user()->can("customer_management")) {
            $status = DB::table('md_dropdowns')->where('slug', 'status_data')->get();
            $users = User::where('role_id', Role::where('role_type', 'customer')->value('id'))->orderBY('id', 'desc')->get();

            return view("users.users_list")->with(["users" => $users, 'status' => $status]);
        } else {
            return redirect()
                ->route("dashboard")
                ->with(
                    "warning",
                    "You do not have permission for this action!"
                );
        }
    }
    public function viewUser($id)
    {
        if (Auth::user()->can("view_customer")) {
            $status = DB::table('md_dropdowns')->where('slug', 'status_data')->get();
            $user = User::find($id);
            return view("users.view_user", compact("user", "status"));
        } else {
            return redirect()
                ->route("dashboard")
                ->with(
                    "warning",
                    "You do not have permission for this action!"
                );
        }
    }

    public function editUser($id)
    {
        if (Auth::user()->can("edit_customer")) {
            $status = DB::table('md_dropdowns')->where('slug', 'status_data')->get();
            $user = User::find($id);
            return view("users.edit_user", compact("user", "status"));
        } else {
            return redirect()
                ->route("dashboard")
                ->with(
                    "warning",
                    "You do not have permission for this action!"
                );
        }
    }

    public function updateUser(Request $request)
    {

        $date = str_replace("/", "-", $request->dob);

        $dob = date('Y-m-d H:00:00', strtotime($date));
        // dd($dob);
        $user = User::find($request->id);
        $user->first_name = $request->first_name;
        $user->last_name = $request->last_name;
        $user->email = $request->email;
        $user->phone_number = $request->phone_number;
        $user->country = $request->country_code;
        $user->status = $request->status;
        $user->dob = $dob;
        $user->is_user_locked = $request->is_user_locked;
        if ($request->password) {
            $user->password = \Hash::make($request->password);
        }

        if ($user->save()) {
            return redirect()
                ->route("users_list")
                ->with([
                    "success" =>
                    "Customer details has been updated successfully!",
                ]);
        } else {
            return redirect()
                ->back()
                ->with("warning", "Something went wrong!");
        }
    }

    public function addUser()
    {
        return view("users.add_user");
    }

    public function saveUser(Request $request)
    {
        $user = new User();
        $user->first_name = $request->first_name;
        $user->last_name = $request->last_name;
        $user->email = $request->email;
        $user->phone_number = $request->phone_number;
        $user->country = $request->country_code;
        $user->role_id = $request->role_id;
        $user->age = $request->age;
        $user->password = \Hash::make($request->password);

        if ($user->save()) {
            return redirect()
                ->route("users_list")
                ->with("success", "Customer has been added successfully!");
        } else {
            return redirect()
                ->back()
                ->with("warning", "Something went wrong!");
        }
    }

    public function checkUserEmail(Request $request)
    {
        $email = User::withTrashed()->where("email", $request->email)->get();
        if (count($email) > 0) {
            $res = 1;
            return response()->json(["msg" => $res]);
        } else {
            $res = 0;
            return response()->json(["msg" => $res]);
        }
    }

    public function checkUserPhoneNumber(Request $request)
    {

        $number = User::withTrashed()->where("phone_number", $request->number)->get();
        if (count($number) > 0) {
            $res = 1;
            return response()->json(["msg" => $res]);
        } else {
            $res = 0;
            return response()->json(["msg" => $res]);
        }

    }

    public function deleteUser(Request $request)
    {
        $deleteUser = User::where("id", $request->id)->delete();
        if ($deleteUser) {
            $res["success"] = 1;
            return json_encode($res);
        } else {
            $res["success"] = 0;
            return json_encode($res);
        }
    }

    //deletedUsersList
    public function deletedUsersList()
    {
        if (Auth::user()->can("manage_recyle_customer_tab")) {

            $usersList = User::where("role_id", Role::where('role_type', 'customer')->value('id'))
                ->orderBY("id", "desc")
                ->onlyTrashed()
                ->get();

            return view("users/deleted_users_list", compact("usersList"));

        } else {
            return redirect()
                ->route("dashboard")
                ->with(
                    "warning",
                    "You do not have permission for this action!"
                );
        }
    }

    //Restore User
    public function restoreUser(Request $request)
    {
        $usersList = User::withTrashed()
            ->find($request->id)
            ->restore();
        return "success";
    }

    //Permanent Delete User
    public function permanentDeleteUser(Request $request)
    {
        $usersList = User::onlyTrashed()
            ->find($request->id)
            ->forceDelete();
        return "success";
    }
}
