<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Blog;

class BlogController extends Controller
{
    public function blogList()
    {
        $blogs = Blog::orderBy("updated_at", "DESC")->get();
        return view("blogs.list", compact("blogs"));
    }

    public function addBlog()
    {
        return view("blogs.add");
    }

    public function saveBlog(Request $request)
    {
        $thumbnail = null;
        $banner = null;
        if ($request->file("thumbnail")) {
            $blogThumbnail = $request->file("thumbnail");
            $thumbnail =
                time() . "." . $blogThumbnail->getClientOriginalExtension();
            $blogThumbnail->move("blogs/thumbnail", $thumbnail);
        }

        if ($request->file("banner")) {
            $blogBanner = $request->file("banner");
            $banner = time() . "." . $blogBanner->getClientOriginalExtension();
            $blogBanner->move("blogs/banner", $banner);
        }

        $blog = new Blog();
        $blog->title_en = $request->title_en;
        $blog->title_ar = $request->title_ar;
        $blog->content_en = $request->content_en;
        $blog->content_ar = $request->content_ar;
        $blog->thumbnail = $thumbnail;
        $blog->banner = $banner;

        if ($blog->save()) {
            return redirect()
                ->route("blogs.list")
                ->with(["success" => "Blog has been added successfully !"]);
        } else {
            return redirect()
                ->back()
                ->with("warning", "Something went wrong!");
        }
    }

    public function updateBlog(Request $request)
    {
        // return $request->input();

        $blog = Blog::where("id", $request->blog_id)->first();

        $blog->title_en = $request->title_en;
        $blog->title_ar = $request->title_ar;
        $blog->content_en = $request->content_en;
        $blog->content_ar = $request->content_ar;

        if ($request->file("thumbnail")) {
            $blogThumbnail = $request->file("thumbnail");
            $thumbnail =
                rand() .
                time() .
                "." .
                $blogThumbnail->getClientOriginalExtension();
            $blogThumbnail->move("blogs/thumbnail", $thumbnail);

            $blog->thumbnail = $thumbnail;
        }

        if ($request->file("banner")) {
            $blogBanner = $request->file("banner");
            $banner =
                rand() .
                time() .
                "." .
                $blogBanner->getClientOriginalExtension();
            $banner_data = $blogBanner->move("blogs/banner", $banner);

            $blog->banner = $banner;
        }

        if ($blog->update()) {
            return redirect()
                ->route("blogs.list")
                ->with(["success" => "Blog has been updated successfully !"]);
        } else {
            return redirect()
                ->back()
                ->with("warning", "Something went wrong!");
        }
    }

    public function editBlog($id)
    {
        $blog = Blog::find($id);
        return view("blogs.edit", compact("blog"));
    }

    public function viewBlog($id)
    {
        $blog = Blog::find($id);
        return view("blogs.view", compact("blog"));
    }

    public function deleteBlog(Request $request)
    {
        $deleteBlog = Blog::where("id", $request->id)->delete();
        if ($deleteBlog) {
            $res["success"] = 1;
            return json_encode($res);
        } else {
            $res["success"] = 0;
            return json_encode($res);
        }
    }

    //deletedCategoryList
    public function deletedBlogList()
    {
        $blogList = Blog::orderBY("id", "desc")
            ->onlyTrashed()
            ->get();
        //dd($usersList);
        return view("blogs.deleted_blogs_list", compact("blogList"));
    }

    //Restore Category
    public function restoreBlog(Request $request)
    {
        $blogList = Blog::withTrashed()
            ->find($request->id)
            ->restore();
        return "success";
    }

    //Permanent Delete Category
    public function permanentDeleteBlog(Request $request)
    {
        $blogList = Blog::onlyTrashed()
            ->find($request->id)
            ->forceDelete();
        return "success";
    }
}
