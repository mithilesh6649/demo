<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Driver;
use Auth;
class DriverController extends Controller
{
    public function list(){
 if (Auth::user()->can("drivers_management")) {

        $list=Driver::orderBy('created_at','DESC')->get();
        return view('misc.drivers.list',compact('list'));
          } else {
            return redirect()
                ->route("dashboard")
                ->with(
                    "warning",
                    "You do not have permission for this action!"
                );
        }
    }

    public function add(){
 if (Auth::user()->can("add_driver")) {
        return view('misc.drivers.add');
       } else {
            return redirect()
                ->route("dashboard")
                ->with(
                    "warning",
                    "You do not have permission for this action!"
                );
        }

    }

    public function saves(Request $request){

        $owner=new Driver();
        $owner->drivers_name=$request->driver;
        $owner->status=1;
        $owner->save();

        return redirect()->route('drivers.list')->with(['status'=>'Driver Name add successfully']);

    }

    public function views($id){
 if (Auth::user()->can("view_driver")) {
      
        $driver=Driver::where('id',$id)->first();
         return view('misc.drivers.view',compact('driver'));
          } else {
            return redirect()
                ->route("dashboard")
                ->with(
                    "warning",
                    "You do not have permission for this action!"
                );
        }

    }

     public function edit($id){
     if (Auth::user()->can("edit_driver")) {
         $driver=Driver::where('id',$id)->first();
         return view('misc.drivers.edit',compact('driver'));
          } else {
            return redirect()
                ->route("dashboard")
                ->with(
                    "warning",
                    "You do not have permission for this action!"
                );
        }

    }

    public function updates(Request $request)
    {
        $owner=Driver::where('id',$request->id)->first();
        $owner->drivers_name=$request->driver;
        $owner->status=$request->status;
        $owner->update();

        return redirect()->route('drivers.list')->with(['status'=>'Driver details update successfully']);
    }

    public function deletes(Request $request)
    {
        $driver=Driver::where('id',$request->id)->first();
        if($driver)
        {
            $driver->delete();
                return response()->json(['success'=>1]);
        
        }else{
            return response()->json(['success'=>0]);
           
        }
    }



    
         //deletedOfferList
    public function deletedDriversList()
    {
         if (Auth::user()->can("manage_recyle_drivers_tab")) {
         
         $allDrivers =  Driver::onlyTrashed()->get();
     
        return view('misc.drivers.deleted_list', compact("allDrivers"));
        } else {
            return redirect()
                ->route("dashboard")
                ->with(
                    "warning",
                    "You do not have permission for this action!"
                );
        }
    }

    //Restore Offer
    public function restoreDrivers(Request $request)
    {
        Driver::withTrashed()
            ->find($request->id)
            ->restore();
        return "success";
    }

    //Permanent Delete Offer
    public function permanentDeleteDrivers(Request $request)
    {
        Driver::onlyTrashed()
            ->find($request->id)
            ->forceDelete();
        return "success";
    }









}
 