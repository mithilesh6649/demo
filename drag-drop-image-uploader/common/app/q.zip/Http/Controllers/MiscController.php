<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\City,Auth;
use App\Models\DailyPettyExpenseCategory;
use App\Models\DailyPettyExpenseSubCategory;
use App\Models\MaintenanceCategory;
use App\Models\MaintenanceSubCategory;
use App\Models\Designation;
use DB;
use Illuminate\Support\Str;

// use Auth;
class MiscController extends Controller
{

public function citiesList(Request $request){
        if (Auth::user()->can("cities_management")) {

            $citiesList = City::get();
             return view('misc.cities.cities_list',compact('citiesList'));
              } else {
            return redirect()
                ->route("dashboard")
                ->with(
                    "warning",
                    "You do not have permission for this action!"
                );
        }
  }


  public function addCity(){
        if (Auth::user()->can("add_city")) {

    return view('misc.cities.add_city');
     } else {
            return redirect()
                ->route("dashboard")
                ->with(
                    "warning",
                    "You do not have permission for this action!"
                );
        }
  }

  public function saveCity(Request $request){

       $city  =   City::create($request->all());

        return redirect()
                ->route("cities_list")
                ->with("success", "City has been added successfully!");

  }


  public function checkCityExist(Request $request){



        $city = City::where('city', $request->city)->get();
        if (count($city) > 0) {
            $res = 1;
            return response()->json(['msg' => $res]);
        } else {
            $res = 0;
            return response()->json(['msg' => $res]);
        }


    }



  public function viewCity($id){
        if (Auth::user()->can("view_city")) {

          $city = City::where('id',$id)->first();
          return view('misc.cities.view_city',compact('city'));
          } else {
            return redirect()
                ->route("dashboard")
                ->with(
                    "warning",
                    "You do not have permission for this action!"
                );
        }
  }


  public function editCity($id){
        if (Auth::user()->can("edit_city")) {

           $city = City::where('id',$id)->first();
          return view('misc.cities.edit_city',compact('city'));
            } else {
            return redirect()
                ->route("dashboard")
                ->with(
                    "warning",
                    "You do not have permission for this action!"
                );
        }
  }


  public function updateCity(Request $request){
              $current_city =   City::where('id',$request->id)->first();
              $current_city->city = $request->city;
              $current_city->city_ar = $request->city_ar;
              $current_city->status = $request->status;
              $current_city->update();

                return redirect()
                ->route("cities_list")
                ->with("success", "City has been updated successfully!");

   }


   //Delete City
       public function deleteCity(Request $request)
       {

           $del_currency = City::where('id',$request->id)->delete();
           return response()->json(['success' => 1]);
       }




            //deleted city list
      public function deletedCityList(Request $request){
        if (Auth::user()->can("manage_recyle_cities_tab")) {

        $deletedCities = City::onlyTrashed()->get();
        return view('misc.cities.deleted_cities_list',compact('deletedCities'));
        } else {
            return redirect()
                ->route("dashboard")
                ->with(
                    "warning",
                    "You do not have permission for this action!"
                );
        }

      }

     //Restore Deleted City
    public function restoreCity(Request $request){
        $City = City::withTrashed()->find($request->id)->restore();
        return "success";
    }




    //Permanent Delete  City
    public function permanentDeleteCity(Request $request)
    {
         $City = City::onlyTrashed()->find($request->id)->forceDelete();
         return "success";
     }




  //For Expense Category..............


 public function ExpenseCategoryList(Request $request){
       if (Auth::user()->can("petty_exp_category_management")) {

            $citiesList = DailyPettyExpenseCategory::get();
             return view('misc.expense_category.list',compact('citiesList'));
             } else {
            return redirect()
                ->route("dashboard")
                ->with(
                    "warning",
                    "You do not have permission for this action!"
                );
        }
  }


  public function addExpenseCategory(){
     if (Auth::user()->can("add_petty_exp_category")) {

    return view('misc.expense_category.add');
     } else {
            return redirect()
                ->route("dashboard")
                ->with(
                    "warning",
                    "You do not have permission for this action!"
                );
        }
  }



  public function saveExpenseCategory(Request $request){
       $city  =   DailyPettyExpenseCategory::create($request->all());

        return redirect()
                ->route("expense_category_list")
                ->with("success", "Petty Expense Category has been added successfully!");

  }



  public function updateExpenseCategory(Request $request){
       $city  =   DailyPettyExpenseCategory::where('id',$request->id)->first()->update($request->all());

        return redirect()
                ->route("expense_category_list")
                ->with("success", "Petty Expense Category has been updated successfully!");

  }





    public function viewExpenseCategory($id){
        if (Auth::user()->can("view_petty_exp_category")) {

          $city = DailyPettyExpenseCategory::where('id',$id)->first();
          return view('misc.expense_category.view',compact('city'));
          } else {
            return redirect()
                ->route("dashboard")
                ->with(
                    "warning",
                    "You do not have permission for this action!"
                );
        }
  }


  public function editExpenseCategory($id){
     if (Auth::user()->can("edit_petty_exp_category")) {

           $city = DailyPettyExpenseCategory::where('id',$id)->first();
          return view('misc.expense_category.edit',compact('city'));
            } else {
            return redirect()
                ->route("dashboard")
                ->with(
                    "warning",
                    "You do not have permission for this action!"
                );
        }
  }




   //Delete City 
       public function deleteExpenseCategory(Request $request)
       {
           
           $del_expense_cate = DailyPettyExpenseCategory::where('id',$request->id)->first();
           $del_expense_cate->subcategories->each(function($subcat){
             $subcat->delete();
           });

            if($del_expense_cate->delete())
            {
                return response()->json(['success' => 1]);
            }




          // $del_currency = DailyPettyExpenseCategory::where('id',$request->id)->delete();
          // return response()->json(['success' => 1]);
       }




                //deletedList
    public function deletedExpenseCategoryList()
    {
       //  if (Auth::user()->can("manage_recyle_drivers_tab")) {
         
         $DailyPettyExpenseCategory =  DailyPettyExpenseCategory::onlyTrashed()->get();
     
        return view('misc.expense_category.deleted_list', compact("DailyPettyExpenseCategory"));
        // } else {
        //     return redirect()
        //         ->route("dashboard")
        //         ->with(
        //             "warning",
        //             "You do not have permission for this action!"
        //         );
        // }
    }

    //Restore 
    public function restoreExpenseCategory(Request $request)
    {
        DailyPettyExpenseCategory::withTrashed()
            ->find($request->id)
            ->restore();
        return "success";
    }

    //Permanent Delete  
    public function permanentDeleteExpenseCategory(Request $request)
    {
        DailyPettyExpenseCategory::onlyTrashed()
            ->find($request->id)
            ->forceDelete();
        return "success";
    }







    //ExpenseSubCategoryList






    public function ExpenseSubCategoryList(Request $request){
        if (Auth::user()->can("petty_exp_sub_category_management")) {

            $citiesList = DailyPettyExpenseSubCategory::with('category')->get();
            //dd($citiesList);
             return view('misc.expense_sub_category.list',compact('citiesList'));
             } else {
            return redirect()
                ->route("dashboard")
                ->with(
                    "warning",
                    "You do not have permission for this action!"
                );
        }
  }


  public function addExpenseSubCategory(){
     if (Auth::user()->can("add_petty_exp_sub_category")) {

       $DailyPettyExpenseCategory  = DailyPettyExpenseCategory::where('status','1')->get();

    return view('misc.expense_sub_category.add',compact('DailyPettyExpenseCategory'));
     } else {
            return redirect()
                ->route("dashboard")
                ->with(
                    "warning",
                    "You do not have permission for this action!"
                );
        }
  }



  public function saveExpenseSubCategory(Request $request){
       $city  =   DailyPettyExpenseSubCategory::create($request->all());

        return redirect()
                ->route("expense_sub_category_list")
                ->with("success", "Petty Expense  Sub Category has been added successfully!");

  }



  public function updateExpenseSubCategory(Request $request){


       $city  =   DailyPettyExpenseSubCategory::where('id',$request->id)->first()->update($request->all());

        return redirect()
                ->route("expense_sub_category_list")
                ->with("success", "Petty Expense Sub Category has been updated successfully!");

  }





    public function viewExpenseSubCategory($id){
        if (Auth::user()->can("view_petty_exp_sub_category")) {
       $DailyPettyExpenseCategory  = DailyPettyExpenseCategory::where('status','1')->get();

          $city = DailyPettyExpenseSubCategory::where('id',$id)->first();
          return view('misc.expense_sub_category.view',compact('city','DailyPettyExpenseCategory'));
          } else {
            return redirect()
                ->route("dashboard")
                ->with(
                    "warning",
                    "You do not have permission for this action!"
                );
        }
  }


  public function editExpenseSubCategory($id){
        if (Auth::user()->can("edit_petty_exp_sub_category")) {
       $DailyPettyExpenseCategory  = DailyPettyExpenseCategory::where('status','1')->get();

           $city = DailyPettyExpenseSubCategory::where('id',$id)->first();
          return view('misc.expense_sub_category.edit',compact('city','DailyPettyExpenseCategory'));
            } else {
            return redirect()
                ->route("dashboard")
                ->with(
                    "warning",
                    "You do not have permission for this action!"
                );
        }
  }




   //Delete City
    public function deleteExpenseSubCategory(Request $request)
    {
  
       $del_currency = DailyPettyExpenseSubCategory::where('id',$request->id)->delete();
       return response()->json(['success' => 1]);
    }
   



                //deletedList
    public function deletedExpenseSubCategoryList()
    {
       //  if (Auth::user()->can("manage_recyle_drivers_tab")) {
         
         $DailyPettyExpenseSubCategory =  DailyPettyExpenseSubCategory::onlyTrashed()->get();
     
        return view('misc.expense_sub_category.deleted_list', compact("DailyPettyExpenseSubCategory"));
        // } else {
        //     return redirect()
        //         ->route("dashboard")
        //         ->with(
        //             "warning",
        //             "You do not have permission for this action!"
        //         );
        // }
    }

    //Restore 
    public function restoreExpenseSubCategory(Request $request)
    {
        DailyPettyExpenseSubCategory::withTrashed()
            ->find($request->id)
            ->restore();
        return "success";
    }

    //Permanent Delete  
    public function permanentDeleteExpenseSubCategory(Request $request)
    {
        DailyPettyExpenseSubCategory::onlyTrashed()
            ->find($request->id)
            ->forceDelete();
        return "success";
    }






   /* Maintenance Report */

    public function MaintenanceCategoryList(){
         if (Auth::user()->can("maintenance_report_category_management")) {
        $MaintenanceCategoryList = MaintenanceCategory::all();
        return view('misc.maintenance_category.list',compact('MaintenanceCategoryList'));
        } else {
            return redirect()
                ->route("dashboard")
                ->with(
                    "warning",
                    "You do not have permission for this action!"
                );
        }

    }


    public function addMaintenanceCategory(){
           if (Auth::user()->can("add_maintenance_category")) {
          return view('misc.maintenance_category.add');
          } else {
            return redirect()
                ->route("dashboard")
                ->with(
                    "warning",
                    "You do not have permission for this action!"
                );
        }
    }


    public function saveMaintenanceCategory(Request $request){

       $MaintenanceCategory  =   MaintenanceCategory::create($request->all());

        return redirect()
                ->route("maintenance_category_list")
                ->with("success", "Maintenance Category has been added successfully!");
    }


    public function deleteMaintenanceCategory(Request $request){
         $MaintenanceCategory = MaintenanceCategory::where('id',$request->id)->delete();
         return response()->json(['success' => 1]);
    }


    public function viewMaintenanceCategory($id){
         if (Auth::user()->can("view_maintenance_category")) {
          $MaintenanceCategory  = MaintenanceCategory::where('id',$id)->first();
          return view('misc.maintenance_category.view',compact('MaintenanceCategory'));
          } else {
            return redirect()
                ->route("dashboard")
                ->with(
                    "warning",
                    "You do not have permission for this action!"
                );
        }
    }

    public function editMaintenanceCategory($id){
          if (Auth::user()->can("edit_maintenance_category")) {
          $MaintenanceCategory = MaintenanceCategory::where('id',$id)->first();
          return view('misc.maintenance_category.edit',compact('MaintenanceCategory'));
          } else {
            return redirect()
                ->route("dashboard")
                ->with(
                    "warning",
                    "You do not have permission for this action!"
                );
        }
    }


     public function updateMaintenanceCategory(Request $request){
       $city  =   MaintenanceCategory::where('id',$request->id)->first()->update($request->all());

        return redirect()
                ->route("maintenance_category_list")
                ->with("success", "Maintenance Category has been updated successfully!");
  }



                  //deletedList
    public function deletedMaintenanceCategoryList()
    {
         if (Auth::user()->can("manage_recyle_maintenance_category_tab")) {
         
         $MaintenanceCategory =  MaintenanceCategory::onlyTrashed()->get();
     
        return view('misc.maintenance_category.deleted_list', compact("MaintenanceCategory"));
        } else {
            return redirect()
                ->route("dashboard")
                ->with(
                    "warning",
                    "You do not have permission for this action!"
                );
        }
    }

    //Restore 
    public function restoreMaintenanceCategory(Request $request)
    {
        MaintenanceCategory::withTrashed()
            ->find($request->id)
            ->restore();
        return "success";
    }

    //Permanent Delete  
    public function permanentDeleteMaintenanceCategory(Request $request)
    {
        MaintenanceCategory::onlyTrashed()
            ->find($request->id)
            ->forceDelete();
        return "success";
    }




  // Maintenance Sub-Category //

    public function MaintenanceSubCategoryList(){ 
      
       if (Auth::user()->can("maintenance_report_sub_category_management")) {
        $MaintenanceSubCategoryList = MaintenanceSubCategory::query();

        $MaintenanceSubCategoryList->with('category');

        $MaintenanceSubCategoryList->wherehas('category',function($query)
        {
            $query->where('status',1);
        });

        $MaintenanceSubCategoryList = $MaintenanceSubCategoryList->get();

        return view('misc.maintenance_sub_category.list',compact('MaintenanceSubCategoryList'));
        } else {
            return redirect()
                ->route("dashboard")
                ->with(
                    "warning",
                    "You do not have permission for this action!"
                );
        }

    }


    public function addMaintenanceSubCategory(){
         if (Auth::user()->can("add_maintenance_sub_category")) {
        $MaintenanceCategoryList = MaintenanceCategory::where('status',1)->get();
        return view('misc.maintenance_sub_category.add',compact('MaintenanceCategoryList'));
        } else {
            return redirect()
                ->route("dashboard")
                ->with(
                    "warning",
                    "You do not have permission for this action!"
                );
        }
    }


    public function checkMaintenanceSubCategoryExist(Request $request){

        $maintenance_sub_category = MaintenanceSubCategory::where(['sub_cat_name'=>$request->sub_cat_name,'cat_id'=>$request->cat_id,'status' =>1])->first();

        if($maintenance_sub_category != null){
            return json_encode(['msg'=>1]);
        }else{
            return json_encode(['msg'=>0]);
        }
    }

    public function saveMaintenanceSubCategory(Request $request){

    $MaintenanceCategory = MaintenanceSubCategory::create($request->all());

        return redirect()
                ->route("maintenance_sub_category_list")
                ->with("success", "Maintenance Sub Category has been added successfully!");
    }


    public function deleteMaintenanceSubCategory(Request $request){
        $MaintenanceSubCategory = MaintenanceSubCategory::where('id',$request->id)->delete();
        return response()->json(['success' => 1]);
    }


    public function viewMaintenanceSubCategory($id){
         if (Auth::user()->can("view_maintenance_sub_category")) {
        $MaintenanceSubCategory  = MaintenanceSubCategory::where('id',$id)->first();
        return view('misc.maintenance_sub_category.view',compact('MaintenanceSubCategory'));
        } else {
            return redirect()
                ->route("dashboard")
                ->with(
                    "warning",
                    "You do not have permission for this action!"
                );
        }
    }

    public function editMaintenanceSubCategory($id){
         if (Auth::user()->can("edit_maintenance_sub_category")) {
        $MaintenanceCategory = MaintenanceCategory::where('status',1)->get();
        $MaintenanceSubCategory = MaintenanceSubCategory::where('id',$id)->first();
        return view('misc.maintenance_sub_category.edit',compact('MaintenanceCategory','MaintenanceSubCategory'));
        } else {
            return redirect()
                ->route("dashboard")
                ->with(
                    "warning",
                    "You do not have permission for this action!"
                );
        }
    }


    public function updateMaintenanceSubCategory(Request $request){
    $MaintenanceSubCategory = MaintenanceSubCategory::where('id',$request->id)->first()->update($request->all());

        return redirect()
                ->route("maintenance_sub_category_list")
                ->with("success", "Maintenance Sub Category has been updated successfully!");

    }



                      //deletedList
    public function deletedMaintenanceSubCategoryList()
    {
         if (Auth::user()->can("manage_recyle_maintenance_sub_category_tab")) {
         
         $MaintenanceSubCategory =  MaintenanceSubCategory::onlyTrashed()->get();
     
        return view('misc.maintenance_sub_category.deleted_list', compact("MaintenanceSubCategory"));
        } else {
            return redirect()
                ->route("dashboard")
                ->with(
                    "warning",
                    "You do not have permission for this action!"
                );
        }
    }

    //Restore 
    public function restoreMaintenanceSubCategory(Request $request)
    {
        MaintenanceSubCategory::withTrashed()
            ->find($request->id)
            ->restore();
        return "success";
    }

    //Permanent Delete  
    public function permanentDeleteMaintenanceSubCategory(Request $request)
    {
        MaintenanceSubCategory::onlyTrashed()
            ->find($request->id)
            ->forceDelete();
        return "success";
    }





  // ------Designations---------------- //
  

  public function designationsList(){
     // if (Auth::user()->can("drivers_management")) {
 
        $list=Designation::orderBy('created_at','DESC')->get();
        return view('misc.designations.list',compact('list'));
        //   } else {
        //     return redirect()
        //         ->route("dashboard")
        //         ->with(
        //             "warning",
        //             "You do not have permission for this action!"
        //         );
        // }
    }

    public function designationsAdd(){
 // if (Auth::user()->can("add_driver")) {
        return view('misc.designations.add');
       // } else {
       //      return redirect()
       //          ->route("dashboard")
       //          ->with(
       //              "warning",
       //              "You do not have permission for this action!"
       //          );
       //  }

    }

    public function designationsSave(Request $request){

        $owner=new Designation();
        $owner->designation=$request->designation;
        $owner->status=1;
        $owner->save();

        return redirect()->route('designations.list')->with(['status'=>'Designation added successfully !']);

    }

    public function designationsView($id){
 // if (Auth::user()->can("view_driver")) {
      
        $designation=Designation::where('id',$id)->first();
         return view('misc.designations.view',compact('designation'));
        //   } else {
        //     return redirect()
        //         ->route("dashboard")
        //         ->with(
        //             "warning",
        //             "You do not have permission for this action!"
        //         );
        // }

    }

     public function designationsEdit($id){
     // if (Auth::user()->can("edit_driver")) {
         $designations=Designation::where('id',$id)->first();
         return view('misc.designations.edit',compact('designations'));
        //   } else {
        //     return redirect()
        //         ->route("dashboard")
        //         ->with(
        //             "warning",
        //             "You do not have permission for this action!"
        //         );
        // }

    }

    public function designationsUpdate(Request $request)
    {
        $designation=Designation::where('id',$request->id)->first();
        $designation->designation=$request->designation;
        $designation->status=$request->status;
        $designation->update();

        return redirect()->route('designations.list')->with(['status'=>'Designation has been updated successfully !']);
    }

    public function designationsDelete(Request $request)
    {
        $designation=Designation::where('id',$request->id)->first();
        if($designation)
        {
            $designation->delete();
                return response()->json(['success'=>1]);
        
        }else{
            return response()->json(['success'=>0]);
           
        }
    }

  
   //checkDesignationsExist

      public function checkDesignationsExist(Request $request){



        $designation = Designation::where('designation', $request->designation)->get();
        if (count($designation) > 0) {
            $res = 1;
            return response()->json(['msg' => $res]);
        } else {
            $res = 0;
            return response()->json(['msg' => $res]);
        }


    }


    
         //deletedList
    public function deletedDesignationsList()
    {
         if (Auth::user()->can("manage_recyle_designations_tab")) {
         
         $Designation =  Designation::onlyTrashed()->get();
     
        return view('misc.designations.deleted_list', compact("Designation"));
        } else {
            return redirect()
                ->route("dashboard")
                ->with(
                    "warning",
                    "You do not have permission for this action!"
                );
        }
    }

    //Restore 
    public function restoreDesignations(Request $request)
    {
        Designation::withTrashed()
            ->find($request->id)
            ->restore();
        return "success";
    }

    //Permanent Delete  
    public function permanentDeleteDesignations(Request $request)
    {
        Designation::onlyTrashed()
            ->find($request->id)
            ->forceDelete();
        return "success";
    }


 //-----End Designations ---------------//


}

