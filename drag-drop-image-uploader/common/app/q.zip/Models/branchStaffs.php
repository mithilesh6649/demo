<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class branchStaffs extends Model
{
    use HasFactory;

   
    public function Staff(){
      return  $this->hasOne(Staff::class,'id','staff_id');
    }

    public function StaffBranch(){
      return  $this->hasOne(Branch::class,'id','branch_id');
    }

     



}
