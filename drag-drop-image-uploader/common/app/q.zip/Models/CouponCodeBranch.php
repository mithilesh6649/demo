<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CouponCodeBranch extends Model
{
    use HasFactory;

     public function  Branch() {
        return $this->belongsTo(Branch::class);
    }

    
     public function  CouponCode() {
        return $this->belongsTo(CouponCode::class);
    }



   

}
